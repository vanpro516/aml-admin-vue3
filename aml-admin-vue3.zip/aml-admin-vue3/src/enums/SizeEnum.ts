/**
 * 布局大小枚举
 */
export const enum SizeEnum {
  /**
   * 默认
   */
  DEFAULT = "default",

  /**
   * 大型
   */
  LARGE = "large",

  /**
   * 小型
   */
  SMALL = "small",

  /**
   * 中等
   */
  MEDIUM = "medium",
  /**
   * 最小单元格宽度
   */
  MINCELLWIDTH = 100,
}
