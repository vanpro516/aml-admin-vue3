/**
 * 菜单布局枚举
 */
export const enum LayoutEnum {
  /**
   * 左侧菜单布局
   */
  LEFT = "left",
  /**
   * 顶部菜单布局
   */
  TOP = "top",

  /**
   * 混合菜单布局
   */
  MIX = "mix",
}

/**
 * 对齐方式枚举
 */
export const enum AlignEnum {
  /**
   * 左侧菜单布局
   */
  LEFT = "left",
  /**
   * 顶部菜单布局
   */
  CENTER = "center",

  /**
   * 混合菜单布局
   */
  RIGHT = "right",
}
