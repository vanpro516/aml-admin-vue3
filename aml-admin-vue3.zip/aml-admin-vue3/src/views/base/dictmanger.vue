<template>
  <div class="crud-container"></div>
</template>

<script setup lang="ts"></script>

<style lang="scss" scoped></style>
