<template>
  <div class="crud-container">
    <vxe-modal
      v-model="showUploadModal"
      resize
      destroy-on-close
      showFooter
      title="文件上传"
      width="500px"
      :position="{ top: '20%' }"
      @hide="hideSubEvent"
    >
      <div class="flex-col justify-center">
        <vxe-select
          v-model="selectedVal"
          :options="regulatoryList"
          clearable
          placeholder="选择上传文件类别"
          class="!w-[80%] mr-2 mb-2"
        />
        <el-upload
          v-show="selectedVal"
          v-model:file-list="fileList"
          :http-request="handleUpload"
          :on-remove="handleFileRemove"
          :on-success="handleSuccess"
          :on-error="handleError"
          drag
          multiple
        >
          <el-icon class="el-icon--upload"><upload-filled /></el-icon>
          <div class="el-upload__text">点击或拖动文件到此处上传文件</div>
          <!-- <template #tip>
            <div class="el-upload__tip">jpg/png files with a size less than 500kb</div>
          </template> -->
        </el-upload>
      </div>
      <template v-if="fileList && fileList.length" #footer>
        <vxe-button status="primary" content="完成" @click="hideUpload"></vxe-button>
      </template>
    </vxe-modal>

    <vxe-form
      v-bind="formOptions"
      class="mb-[10px]"
      :data="queryParams"
      @submit="submit"
      @reset="reset"
    ></vxe-form>

    <vxe-table :data="tableData" :size="SizeEnum.MEDIUM" :align="AlignEnum.CENTER" height="500">
      <vxe-column
        v-for="item in columns"
        :key="item.key"
        :fixed="item.fixed"
        :field="item.key"
        :title="item.title"
        :show-overflow="item.overflow"
        :width="item.width ? item.width : ''"
      >
        <template v-if="item.slot === 'regulatoryCategory'" #default="{ row }">
          <span>{{ findLabelByValue(regulatoryList, row.regulatoryCategory) }}</span>
        </template>
        <template v-if="item.slot === 'action'" #default="{ row }">
          <el-button type="primary" link @click="download(row)">下载</el-button>
          <el-button type="primary" link @click="handlePreview(row)">预览</el-button>
        </template>
      </vxe-column>
    </vxe-table>
    <vxe-pager
      v-model:current-page="queryParams.pageNum"
      v-model:page-size="queryParams.pageSize"
      :total="queryParams.totalCount"
      :layouts="tableLayouts"
      @page-change="pageChange1"
    />
    <!-- 预览文件 -->
    <FilePreview
      v-if="visible"
      :url="previewUrl"
      :visible="visible"
      @update:visible="updateVisible"
    />
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { SizeEnum } from "@/enums/SizeEnum";
import { AlignEnum } from "@/enums/LayoutEnum";
import { findLabelByValue } from "@/utils";
// import ImportWorkAPI from "@/api/work";
import type { VxeFormProps } from "vxe-pc-ui";
import { cloneDeep } from "lodash-es";
import { tableLayouts } from "@/utils/constant";
import PageBaseAPI from "@/api/base";

interface RowVO {
  id: number;
  name: string;
  role: string;
  sex: string;
  age: number;
  address: string;
}

const tableData = ref<RowVO[]>([]);
const fileList = ref([]);
const showUploadModal = ref(false);
const handleUpload = ({ file }) => {
  const formData = new FormData();
  formData.append("file", file);
  const current = regulatoryList.find((e) => e.value === selectedVal.value);
  if (current) {
    formData.append("regulatoryCategory", current.value);
    formData.append("regulatoryName", current.label);
  }
  return PageBaseAPI.postLegalDocument(formData).then((res) => {
    return {
      ...res.data,
    };
  });
};
const visible = ref(false);
const previewUrl = ref("");
// 预览文件
const handlePreview = (data: any) => {
  console.log(data, "【 handlePreview 】");
  previewUrl.value =
    "http://172.16.20.174/far-aml-boot/file/zycg_aml/1、国家法律类：中华人民共和国反恐怖主义法(2018修正).docx";
  // const testUrl = "http://172.16.20.174";
  // previewUrl.value = testUrl + data.filePath;
  visible.value = true;
};
const updateVisible = (value: boolean) => {
  visible.value = value;
};
const handleFileRemove = () => {};
const handleSuccess = () => {};
const handleError = () => {};
const hideSubEvent = () => {
  showUploadModal.value = false;
  selectedVal.value = "";
  fileList.value = [];
};
const hideUpload = () => {
  hideSubEvent();
  submit();
};
const regulatoryList = [
  { value: "0", label: "国家法律" },
  { value: "1", label: "部门规章" },
  { value: "2", label: "重要发文" },
  { value: "3", label: "工作批复" },
];
const columns = [
  {
    title: "ID",
    key: "id",
    align: "center",
  },
  {
    title: "文件名",
    key: "fileName",
    align: "center",
    overflow: true,
    width: 500,
  },
  {
    title: "存储路径",
    key: "filePath",
    align: "center",
    overflow: true,
    width: 300,
  },
  {
    title: "文件类别",
    key: "regulatoryCategory",
    slot: "regulatoryCategory",
    align: "center",
  },
  {
    title: "操作",
    align: "center",
    fixed: "right",
    slot: "action",
    width: 120,
  },
];
const formOptions = reactive<VxeFormProps>({
  titleColon: true,
  items: [
    {
      field: "regulatoryCategory",
      title: "文件类别",
      span: 6,
      itemRender: {
        name: "VxeSelect",
        props: { clearable: true },
        options: regulatoryList,
      },
    },
    {
      span: 3,
      itemRender: {
        name: "VxeButtonGroup",
        events: {
          click(slotParams, { name }) {
            if (name === "download") {
              showUploadModal.value = true;
            }
          },
        },
        options: [
          { type: "submit", content: "查询", status: "primary" },
          { type: "reset", content: "重置" },
          { name: "download", content: "文件上传", status: "primary" },
        ],
      },
    },
  ],
});
const selectedVal = ref("");
const submit = () => {
  pageChange1({ currentPage: 1, pageSize: 10 });
};
const reset = () => {
  queryParams.value = { ...defaultParams };
  initData();
};

const defaultParams = {
  regulatoryCategory: "",
  pageNum: 1,
  pageSize: 10,
  current: 1,
  totalCount: 0,
};

const queryParams = ref<any>(cloneDeep(defaultParams));

const download = () => {};

function pageChange1(page) {
  const { currentPage, pageSize } = page;
  queryParams.value.pageNum = currentPage;
  queryParams.value.pageSize = pageSize;
  initData();
}

const initData = () => {
  PageBaseAPI.getLegalPageList({
    pageNum: queryParams.value.pageNum,
    pageSize: queryParams.value.pageSize,
    regulatoryCategory: queryParams.value.regulatoryCategory
      ? queryParams.value.regulatoryCategory
      : undefined,
  }).then((resData) => {
    const { records = [], current, total, pages } = resData;
    console.log(current, pages);
    tableData.value = records;
    queryParams.value.totalCount = total;
  });
};

onMounted(() => {
  initData();
});
</script>
