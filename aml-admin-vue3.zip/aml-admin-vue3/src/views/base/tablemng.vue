<template>
  <div class="crud-container">
    <vxe-form v-bind="formOptions" class="mb-[10px]" @submit="submit" @reset="reset"></vxe-form>

    <vxe-table :data="tableData" :size="SizeEnum.MEDIUM" :align="AlignEnum.CENTER" height="500">
      <vxe-column
        v-for="item in columns"
        :key="item.key"
        :fixed="item.fixed"
        :field="item.key"
        :title="item.title"
        :show-overflow="item.overflow"
        :width="item.width ? item.width : ''"
      >
        <template v-if="item.slot === 'action'" #default="{ row }">
          <el-button type="primary" @click="showDrawerInfo(row)">详情</el-button>
        </template>
      </vxe-column>
    </vxe-table>
    <vxe-pager
      v-model:current-page="queryParams.currentPage"
      v-model:page-size="queryParams.everyCount"
      :total="queryParams.totalCount"
      :layouts="tableLayouts"
      @page-change="pageChange1"
    />

    <vxe-drawer v-model="showDrawer" :title="drawerTitle" width="50%" @hide="hideSubEvent">
      <vxe-table
        border
        height="90%"
        :row-config="{ keyField: 'columnSeq' }"
        :data="drawerTableData"
        :loading="drawerLoading"
      >
        <vxe-column
          v-for="item in drawerColumns"
          :key="item.key"
          :fixed="item.fixed"
          :field="item.key"
          :title="item.title"
          :show-overflow="item.overflow"
          :width="item.width ? item.width : ''"
        ></vxe-column>
      </vxe-table>
      <vxe-pager
        v-model:current-page="queryDrawerParams.currentPage"
        v-model:page-size="queryDrawerParams.everyCount"
        :total="queryDrawerParams.totalCount"
        :layouts="tableLayouts"
        @page-change="pageChange2"
      />
    </vxe-drawer>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { SizeEnum } from "@/enums/SizeEnum";
import { AlignEnum } from "@/enums/LayoutEnum";
import ImportWorkAPI from "@/api/work";
import type { VxeFormProps } from "vxe-pc-ui";
import { cloneDeep } from "lodash-es";
import { tableLayouts } from "@/utils/constant";
import { convertDataJsonForTable, filterObject } from "@/utils";

interface RowVO {
  id: number;
  name: string;
  role: string;
  sex: string;
  age: number;
  address: string;
}

const tableData = ref<RowVO[]>([]);
const columns = [
  {
    title: "目标表名",
    key: "tableName",
    align: "center",
  },
  {
    title: "表类型",
    key: "tableTypeName",
    align: "center",
  },
  {
    title: "表说明",
    key: "tableDesc",
    align: "center",
  },
  {
    title: "时间",
    key: "dInsert",
    align: "center",
  },
  {
    title: "操作",
    align: "center",
    slot: "action",
    width: 120,
  },
];
interface FormDataVO {
  tableName: string;
  tableType?: string;
}

const formOptions = reactive<VxeFormProps<FormDataVO>>({
  titleColon: true,
  data: {
    tableName: "",
  },
  items: [
    {
      field: "tableName",
      title: "表名称",
      span: 6,
      itemRender: {
        name: "VxeInput",
        props: {
          clearable: true,
          placeholder: "表名称",
          prefixIcon: "vxe-icon-search",
        },
      },
    },
    {
      field: "tableType",
      title: "表类型",
      span: 6,
      itemRender: {
        name: "VxeSelect",
        props: { clearable: true, placeholder: "表类型" },
        options: [
          { label: "全部", value: "" },
          { label: "人行规定表", value: "1" },
          { label: "自定义表", value: "2" },
          { label: "模型表", value: "3" },
        ],
      },
    },
    {
      span: 3,
      itemRender: {
        name: "VxeButtonGroup",
        options: [
          { type: "submit", content: "查询", status: "primary" },
          { type: "reset", content: "重置" },
        ],
      },
    },
  ],
});

const submit = () => {
  queryParams.value.currentPage = 1;
  pageChange1(queryParams.value);
};

const reset = () => {
  queryParams.value = { ...defaultParams };
  initData();
};

const defaultParams = {
  currentPage: 1,
  totalCount: 1,
  totalPage: 1,
  isNext: true,
  isLast: false,
  indexCount: 0,
  everyCount: 10,
  whereStr: "{}",
  serviceName: "targetTabServiceImpl",
  conditionList: [],
  paramJson: "{}",
};
const queryParams = ref<any>(cloneDeep(defaultParams));

function pageChange1(page) {
  const { currentPage, pageSize } = page;
  queryParams.value.indexCount = pageSize * currentPage - pageSize;
  initData();
}

const initData = () => {
  queryParams.value.whereStr = JSON.stringify(filterObject({ ...formOptions.data }));
  ImportWorkAPI.getPage(queryParams.value).then((resData) => {
    if (resData?.resObj) {
      const { totalCount, totalPage, everyCount, dataJson } = resData.resObj;
      tableData.value = convertDataJsonForTable(dataJson);
      queryParams.value.totalCount = totalCount;
      queryParams.value.totalPage = totalPage;
      queryParams.value.everyCount = everyCount;
    }
  });
};

// 抽屉相关
const drawerColumns = [
  {
    title: "字段顺序",
    fixed: "left",
    key: "columnSeq",
    align: "center",
    width: 100,
  },
  {
    title: "字段名称",
    key: "columnName",
    align: "center",
    width: 150,
  },
  {
    title: "字段描述",
    key: "columnDesc",
    align: "center",
    width: 200,
  },
  {
    title: "字段类型",
    key: "dataTypeName",
    align: "center",
    width: 100,
  },
  {
    title: "字段长度",
    key: "dataLength",
    align: "center",
    width: 100,
  },
  {
    title: "字典项",
    key: "vItemName",
    align: "center",
    width: 150,
  },
  {
    title: "是否校验",
    key: "ifCheckDictName",
    align: "center",
    width: 100,
  },
  {
    title: "精度",
    key: "dataPrecision",
    align: "center",
    width: 100,
  },
  {
    title: "小数点位数",
    key: "dataScale",
    align: "center",
    width: 120,
  },
  {
    title: "校验格式",
    key: "dateFormat",
    align: "center",
    width: 100,
  },
  {
    title: "分区字段",
    key: "partitionSeqName",
    align: "center",
    width: 100,
  },
];
const drawerTitle = ref("");
const showDrawer = ref(false);
const drawerLoading = ref(false);
const drawerTableData = ref([]);
const defaultDrawerParams = {
  currentPage: 1,
  totalCount: 1,
  totalPage: 1,
  isNext: true,
  isLast: false,
  indexCount: 0,
  everyCount: 10,
  whereStr: "{}",
  serviceName: "targetTabValueServiceImpl",
  conditionList: [],
  paramJson: "{}",
};
const queryDrawerParams = ref<any>(cloneDeep(defaultDrawerParams));
const showDrawerInfo = (row) => {
  console.log(row, 99);
  if (row?.tableName) {
    queryDrawerParams.value.whereStr = JSON.stringify({ tableName: row.tableName });
    drawerTitle.value = `表${row.tableName}字段信息`;
  }
  initDrawer();
};
const hideSubEvent = () => {
  queryDrawerParams.value = cloneDeep(defaultDrawerParams);
  drawerTitle.value = "";
};
const initDrawer = () => {
  drawerLoading.value = true;
  ImportWorkAPI.getPage(queryDrawerParams.value)
    .then((resData) => {
      if (resData?.resObj) {
        const { totalCount, totalPage, everyCount, dataJson } = resData.resObj;
        drawerTableData.value = convertDataJsonForTable(dataJson);
        queryDrawerParams.value.totalCount = totalCount;
        queryDrawerParams.value.totalPage = totalPage;
        queryDrawerParams.value.everyCount = everyCount;
        if (!showDrawer.value) {
          showDrawer.value = true;
        }
      }
    })
    .finally(() => {
      drawerLoading.value = false;
    });
};
const pageChange2 = (page) => {
  const { currentPage, pageSize } = page;
  queryDrawerParams.value.indexCount = pageSize * currentPage - pageSize;
  initDrawer();
};
onMounted(() => {
  initData();
});
</script>
