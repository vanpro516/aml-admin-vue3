<template>
  <div class="crud-container">
    <vxe-form v-bind="formOptions" class="mb-[10px]" @submit="submit"></vxe-form>

    <vxe-table :data="tableData" :size="SizeEnum.MEDIUM" :align="AlignEnum.CENTER" height="500">
      <vxe-column
        v-for="item in columns"
        :key="item.key"
        :fixed="item.fixed"
        :field="item.key"
        :title="item.title"
        :show-overflow="item.overflow"
        :width="item.width ? item.width : ''"
      >
        <template v-if="item.slot === 'action'" #default="{ row }">
          <!-- <el-button type="primary" @click="showDrawerInfo(row)">详情</el-button> -->
        </template>
      </vxe-column>
    </vxe-table>
    <vxe-pager
      v-model:current-page="queryParams.pageNum"
      v-model:page-size="queryParams.pageSize"
      :total="queryParams.totalCount"
      :layouts="tableLayouts"
      @page-change="pageChange1"
    />

    <vxe-drawer v-model="showDrawer" title="模型信息" width="50%" :loading="drawerLoading">
      <vxe-form v-bind="drawerFormOptions" class="mb-[10px]">
        <vxe-form-item title="模型ID" field="ruleId" :item-render="{}">
          <vxe-input v-model="drawerFormData.ruleId" disabled></vxe-input>
        </vxe-form-item>
        <vxe-form-item title="模型名称" field="ruleName" :item-render="{}">
          <vxe-input v-model="drawerFormData.ruleName" disabled></vxe-input>
        </vxe-form-item>
        <vxe-form-item
          v-if="drawerFormData.parmList && drawerFormData.parmList.length"
          title="模型参数"
          field="ruleParm"
          className="self-center"
        >
          <vxe-table border :row-config="{ keyField: 'id' }" :data="drawerFormData.parmList">
            <vxe-column
              v-for="item in columnsForInfo"
              :key="item.key"
              :field="item.key"
              :title="item.title"
              :show-overflow="item.overflow"
              :width="item.width ? item.width : ''"
            >
              <template v-if="item.slot === 'paraValue'" #default="{ row }">
                <vxe-input v-model="row.paraValue"></vxe-input>
              </template>
              <template v-if="item.slot === 'action'" #default="{ row }">
                <el-button type="primary" link @click="updateRow(row)">保存</el-button>
              </template>
            </vxe-column>
          </vxe-table>
        </vxe-form-item>
        <vxe-form-item title="模型描述" field="modelDesc" className="self-center">
          <vxe-textarea
            v-model="drawerFormData.modelDesc"
            :autosize="{ minRows: 2, maxRows: 2 }"
          ></vxe-textarea>
        </vxe-form-item>
        <vxe-form-item title="模型代码" field="ruleProg" className="self-center">
          <vxe-textarea
            v-model="drawerFormData.ruleProg"
            :autosize="{ minRows: 6, maxRows: 6 }"
            disabled
          ></vxe-textarea>
        </vxe-form-item>
        <vxe-form-item className="mx-[100px]">
          <template #default>
            <vxe-button
              type="reset"
              status="primary"
              content="更新"
              @click="updateInfo"
            ></vxe-button>
          </template>
        </vxe-form-item>
      </vxe-form>
    </vxe-drawer>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { SizeEnum } from "@/enums/SizeEnum";
import { AlignEnum } from "@/enums/LayoutEnum";
import ImportWorkAPI from "@/api/work";
import type { VxeFormProps, VxeFormListeners, VxeFormInstance } from "vxe-pc-ui";
import { cloneDeep } from "lodash-es";
import { tableLayouts, columnsForInfo } from "@/utils/constant";
import PageModuleAPI from "@/api/module";
import PageBaseAPI from "@/api/base";

interface RowVO {
  id: number;
  name: string;
  role: string;
  sex: string;
  age: number;
  address: string;
}

const tableData = ref<RowVO[]>([]);
const columns = [
  {
    title: "ID",
    key: "id",
    align: "center",
  },
  {
    title: "表中文名称",
    key: "tableNameZh",
    align: "center",
    width: 120,
  },
  {
    title: "表名称",
    key: "tableNumber",
    align: "center",
    width: 120,
  },
  {
    title: "表名",
    key: "tableNameEn",
    align: "center",
    width: 200,
  },
  {
    title: "字段",
    key: "fieldNameEn",
    width: 120,
    align: "center",
  },
  {
    title: "字段类型",
    key: "fieldTypeLength",
    align: "center",
    width: 120,
  },
  {
    title: "字段名称",
    key: "fieldNameZh",
    align: "center",
    width: 200,
  },
  {
    title: "字段说明",
    key: "fieldDefinition",
    align: "center",
    width: 200,
  },
  {
    title: "规则",
    key: "fillRule",
    align: "center",
    width: 200,
  },
  {
    title: "旧规则",
    key: "ruleIdOld",
    align: "center",
    width: 200,
  },
  {
    title: "新规则",
    key: "ruleIdNew",
    align: "center",
    width: 200,
  },
  {
    title: "校验规则",
    key: "validationRule",
    align: "center",
    width: 200,
  },
  {
    title: "提示",
    key: "prompt",
    align: "center",
    width: 200,
  },
  {
    title: "规则详情",
    key: "standardVersion",
    align: "center",
    width: 200,
  },
  // {
  //   title: "操作",
  //   align: "center",
  //   fixed: "right",
  //   slot: "action",
  //   width: 120,
  // },
];
interface FormDataVO {
  ruleName: string;
}

const formOptions = reactive<VxeFormProps<FormDataVO>>({
  titleColon: true,
  data: {
    tableNameEn: "",
  },
  items: [
    {
      field: "tableNameEn",
      title: "表名",
      span: 6,
      itemRender: {
        name: "VxeInput",
        props: {
          clearable: true,
          placeholder: "例如：TB_ACC",
          prefixIcon: "vxe-icon-search",
        },
      },
    },
    {
      span: 3,
      itemRender: {
        name: "VxeButtonGroup",
        options: [{ type: "submit", content: "查询", status: "primary" }],
      },
    },
  ],
});

const submit = () => {
  queryParams.value.currentPage = 1;
  pageChange1(queryParams.value);
};

const defaultParams = {
  pageNum: 1,
  pageSize: 10,
  current: 1,
  totalCount: 0,
  tableNameEn: "",
};
const queryParams = ref<any>(cloneDeep(defaultParams));
function pageChange1(page) {
  const { currentPage, pageSize } = page;
  initData();
}

const initData = () => {
  PageBaseAPI.getTableMetadata({
    pageNum: queryParams.value.pageNum,
    pageSize: queryParams.value.pageSize,
    tableNameEn: queryParams.value.tableNameEn ? queryParams.value.tableNameEn : undefined,
  }).then((resData) => {
    const { records = [], current, total, pages } = resData;
    tableData.value = records;
    queryParams.value.totalCount = total;
  });
};

// 抽屉相关
const showDrawer = ref(false);
const drawerLoading = ref(false);
const drawerFormData = ref({});
const drawerFormOptions = reactive<VxeFormProps<ModalParams>>({
  titleWidth: 100,
  titleAlign: "right",
  titleColon: true,
  validConfig: { theme: "normal" },
  span: 24,
});
const showDrawerInfo = (info) => {
  drawerFormData.value = info;
  PageModuleAPI.getParmlist({ id: info.ruleId }).then((res) => {
    if (res.state) {
      drawerFormData.value.parmList = res?.resList || [];
      showDrawer.value = true;
    } else {
      ElMessage.error(res?.resMsg || "未知错误");
    }
  });
};
const updateRow = (row) => {
  PageModuleAPI.updateParmRow(row).then((res) => {
    if (res.state) {
      ElMessage.success("保存成功");
    } else {
      ElMessage.error(res?.resMsg || "保存失败");
    }
  });
};
const updateInfo = () => {
  PageModuleAPI.updateRuleDef(drawerFormData.value).then((res) => {
    if (res.state) {
      ElMessage.success("模型信息更新成功");
      showDrawer.value = false;
      submit();
    } else {
      ElMessage.error(res?.resMsg || "模型信息更新失败");
    }
  });
};
onMounted(() => {
  initData();
});
</script>
