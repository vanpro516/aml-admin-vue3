<template>
  <div class="crud-container">
    <!-- 左侧树形目录 -->
    <vxe-card shadow class="left-card">
      <template #title>
        <div class="flex justify-between">
          <div class="flex-y-center">
            <el-icon size="16"><FolderOpened /></el-icon>
            <span class="ml-1">模型目录</span>
          </div>
          <el-dropdown placement="bottom-end" @command="handleCommand">
            <el-icon size="18"><ArrowDown /></el-icon>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="expandAll">全部展开</el-dropdown-item>
                <el-dropdown-item command="collapseAll">全部收起</el-dropdown-item>
                <el-dropdown-item command="selectAll">全选</el-dropdown-item>
                <el-dropdown-item command="deselectAll">全不选</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </template>

      <el-tree
        ref="treeRef"
        show-checkbox
        check-on-click-node
        :node-key="'menuId'"
        :data="treeData"
        :expand-on-click-node="false"
        :props="props"
        :height="208"
      >
        <template #default="{ node, data }">
          <span>{{ node.label }}</span>
        </template>
      </el-tree>
    </vxe-card>
    <vxe-card shadow class="right-card">
      <template #title>
        <div>
          <span>已选模型 ({{ tableData.length }})</span>
        </div>
      </template>
      <vxe-table
        :data="tableData"
        :size="SizeEnum.MEDIUM"
        :align="AlignEnum.CENTER"
        :expand-config="{ accordion: true }"
        :min-height="200"
        :max-height="500"
        @toggle-row-expand="toggleRowExpand"
      >
        <vxe-column type="expand" width="60">
          <template #content="{ row }">
            <div v-if="row.parmList && row.parmList.length" class="p-8 bg-[#f8f8f9]">
              <vxe-table border :row-config="{ keyField: 'id' }" :data="parmList">
                <vxe-column
                  v-for="item in columnsForInfo"
                  :key="item.key"
                  :field="item.key"
                  :title="item.title"
                  :show-overflow="item.overflow"
                  width="25%"
                >
                  <template v-if="item.slot === 'paraValue'" #default="{ row }">
                    <vxe-input v-model="row.paraValue"></vxe-input>
                  </template>
                  <template v-if="item.slot === 'action'" #default="{ row }">
                    <el-button type="primary" @click="updateRow(row)">保存</el-button>
                  </template>
                </vxe-column>
              </vxe-table>
            </div>
            <div v-else class="flex-y-center flex-x-center h-[100px] bg-[#f8f8f9] font-bold">
              <span>未设置模型参数</span>
            </div>
          </template>
        </vxe-column>
        <vxe-column
          v-for="item in columns"
          :key="item.key"
          :field="item.key"
          :title="item.title"
          :show-overflow="item.overflow"
          :width="item.width ? item.width : ''"
        ></vxe-column>
      </vxe-table>

      <div class="flex-x-center mt-[20px]">
        <el-button type="primary" @click="startCheck">开始执行</el-button>
      </div>
    </vxe-card>
  </div>
</template>
<script lang="ts" setup>
import { ref } from "vue";
import { AlignEnum } from "@/enums/LayoutEnum";
import { SizeEnum } from "@/enums/SizeEnum";
import { columnsForInfo } from "@/utils/constant";
import ImportWorkAPI from "@/api/work";
import PageBaseAPI from "@/api/base";
import PageModuleAPI from "@/api/module";
import { useRouter } from "vue-router";

const props = {
  value: "menuId",
  label: "title",
  children: "children",
};
const treeData = ref([]);
const allModelList = ref([]);
const parmList = ref([]); // 当前模型参数
const treeRef = ref();
const router = useRouter();
const getCheckedNodesList = (leafOnly) => {
  const $treeRef = treeRef.value;
  const list = $treeRef.getCheckedNodes(leafOnly).map((e) => e.ruleId);
  return (list || []).map((item) => {
    const current = allModelList.value.find((model) => model.ruleId === item);
    return current;
  });
};
const tableData = computed(() => {
  return treeRef.value ? getCheckedNodesList(true) : [];
});
const columns = [
  {
    title: "模型ID",
    key: "ruleId",
    align: "center",
  },
  {
    title: "模型名称",
    key: "ruleName",
    overflow: true,
    width: 300,
    align: "center",
  },
  {
    title: "模型描述",
    key: "modelDesc",
    align: "center",
    overflow: true,
    width: 400,
  },
];
const init = () => {
  ImportWorkAPI.getRuleTree().then((res) => {
    treeData.value = res?.resList || [];
  });
  PageBaseAPI.getList().then((res) => {
    allModelList.value = res?.resList || [];
  });
};
const toggleRowExpand = ({ expanded, row, rowIndex }) => {
  if (expanded && row && row.parmList && row.parmList.length) {
    PageModuleAPI.getParmlist({ id: row.ruleId }).then((res) => {
      if (res.state) {
        parmList.value = res?.resList || [];
      } else {
        ElMessage.error(res?.resMsg || "未知错误");
      }
    });
  }
};
const updateRow = (row) => {
  PageModuleAPI.updateParmRow(row).then((res) => {
    if (res.state) {
      ElMessage.success("保存成功");
    } else {
      ElMessage.error(res?.resMsg || "保存失败");
    }
  });
};
const startCheck = () => {
  const $treeRef = treeRef.value;
  const data1 = $treeRef.getHalfCheckedNodes();
  const data2 = $treeRef.getCheckedNodes(true);
  const data = [...data1, ...data2];
  console.log("要执行的模型数据>>>", data);
  ImportWorkAPI.ifRunning().then((res) => {
    if (!res.state) {
      ElMessageBox.confirm("有模型正在执行，确定继续提交吗？", "提示", {
        type: "warning",
      }).then(() => {
        execRule(data);
      });
    } else {
      execRule(data);
    }
  });
};
const execRule = (data) => {
  ImportWorkAPI.execRuleRunTree(data).then((result) => {
    if (result.state) {
      router.replace("/checkResult");
    } else {
      ElMessage.error(result.resMsg);
    }
  });
};
const handleCommand = (command) => {
  switch (command) {
    case "expandAll":
      expandAll();
      break;
    case "collapseAll":
      collapseAll();
      break;
    case "selectAll":
      selectAll();
      break;
    case "deselectAll":
      deselectAll();
      break;
  }
};
const expandAll = () => {
  const $treeRef = treeRef.value;
  console.log($treeRef, 999);
  // Object.keys($treeRef.store.nodesMap).forEach((key) => {
  //   console.log("节点ID:", key);
  //   console.log("节点ID:", $treeRef.store.nodesMap[key]);
  // });
};
const collapseAll = () => {
  const $treeRef = treeRef.value;
  $treeRef.store.nodesMap.forEach((node) => {
    node.expanded = false;
  });
};
const selectAll = () => {
  const $treeRef = treeRef.value;
  $treeRef.setCheckedNodes([]);
};
const deselectAll = () => {
  const $treeRef = treeRef.value;
  $treeRef.setCheckedNodes([]);
};

onMounted(() => {
  init();
});
</script>

<style lang="scss" scoped>
.crud-container {
  @apply flex space-x-2;
}
.left-card {
  @apply h-full min-w-[310px] max-w-[310px] flex-x-center text-center;
}
.right-card {
  @apply h-full w-[calc(100%-320px)];
}
</style>
