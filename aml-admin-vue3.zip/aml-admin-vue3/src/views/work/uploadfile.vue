<template>
  <div class="crud-container">
    <vxe-form v-bind="formOptions" v-on="formEvents"></vxe-form>

    <vxe-toolbar class="my-[10px]">
      <template #buttons>
        <vxe-button status="primary" class="ml-[10px]" @click="showImport">本地导入</vxe-button>
      </template>
    </vxe-toolbar>

    <ImportModal
      :visible="showImportModal"
      @stepChange="handleStepChange"
      @update:visible="updateVisible"
    />

    <vxe-table :data="tableData" :size="SizeEnum.MEDIUM" :align="AlignEnum.CENTER" height="70%">
      <vxe-column
        v-for="item in columns"
        :key="item.key"
        :field="item.key"
        :title="item.title"
        :show-overflow="item.overflow"
        :width="item.width ? item.width : ''"
      >
        <template v-if="item.slot === 'tableName'" #default="{ row }">
          <span>{{ row.tableName }}@{{ row.tableDesc }}</span>
        </template>
        <template v-if="item.slot === 'lineError'" #default="{ row }">
          <span :style="{ color: Number(row.lineError) > 0 ? '#fe200c' : '#2b82e4' }">
            {{ row.lineError }}
          </span>
        </template>
        <template v-if="item.slot === 'errMsg'" #default="{ row }">
          <el-dropdown placement="bottom">
            <el-button>操作</el-button>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item :disabled="Number(row.lineError) <= 0" @click="openErrInfo(row)">
                  错误信息汇总
                </el-dropdown-item>
                <el-dropdown-item
                  :disabled="Number(row.lineError) <= 0"
                  @click="downloadFileByFileId(row)"
                >
                  下载错误文件
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </template>
        <template v-if="item.slot === 'action'" #default="{ row }">
          <el-button type="primary" @click="openModal(row)">预览</el-button>
          <el-button type="danger" @click="openConfirm(row)">删除</el-button>
        </template>
      </vxe-column>
    </vxe-table>
    <vxe-pager
      v-model:current-page="queryParams.currentPage"
      v-model:page-size="queryParams.everyCount"
      :total="queryParams.totalCount"
      :layouts="tableLayouts"
      @page-change="pageChange1"
    />

    <vxe-modal
      v-model="showModal"
      resize
      show-maximize
      :title="modalTitle"
      height="650"
      width="1200"
      @hide="hideSubEvent"
    >
      <vxe-table
        border
        height="530px"
        :row-config="{ keyField: 'columnSeq' }"
        :data="tableModalData"
        :loading="modalLoading"
      >
        <vxe-column
          v-for="item in modalColumns"
          :key="item.key"
          :field="item.key"
          :title="item.title"
          :show-overflow="item.overflow"
          :width="item.width ? item.width : ''"
        ></vxe-column>
      </vxe-table>
      <vxe-pager
        v-model:current-page="queryModalParams.currentPage"
        v-model:page-size="queryModalParams.everyCount"
        :total="queryModalParams.totalCount"
        :layouts="tableLayouts"
        @page-change="pageChange2"
      />
    </vxe-modal>
  </div>
</template>

<script setup lang="tsx">
import { ref } from "vue";
import { SizeEnum } from "@/enums/SizeEnum";
import { AlignEnum } from "@/enums/LayoutEnum";
import ImportWorkAPI from "@/api/work";
import { convertDataJsonForTable, downloadFileByFileId } from "@/utils/index";
import type { VxeFormProps, VxeFormListeners } from "vxe-pc-ui";
import { cloneDeep } from "lodash-es";
import ImportModal from "@/views/work/components/ImportModal.vue";
import { tableLayouts } from "@/utils/constant";

interface RowVO {
  id: number;
  name: string;
  role: string;
  sex: string;
  age: number;
  address: string;
}

const tableData = ref<RowVO[]>([]);
const columns = [
  {
    title: "目标表名",
    slot: "tableName",
    align: "center",
  },
  {
    title: "状态",
    key: "status",
    align: "center",
    width: 150,
  },
  {
    title: "成功行数",
    key: "lineSucc",
    align: "center",
    width: 100,
  },
  {
    title: "失败行数",
    slot: "lineError",
    align: "center",
    width: 100,
  },
  {
    title: "写入时间",
    key: "DInsert",
    align: "center",
    width: 200,
  },
  {
    title: "原始路径",
    key: "oriPath",
    overflow: true,
    width: 200,
    align: "center",
  },
  {
    title: "错误信息",
    slot: "errMsg",
    align: "center",
    width: 150,
  },
  {
    title: "操作",
    align: "center",
    slot: "action",
    width: 160,
  },
];
interface FormDataVO {
  tableName: string;
}

const formOptions = reactive<VxeFormProps<FormDataVO>>({
  data: {
    tableName: "",
  },
  items: [
    { field: "tableName", title: "目标表名", span: 8, itemRender: { name: "VxeInput" } },
    {
      span: 8,
      itemRender: {
        name: "VxeButtonGroup",
        options: [
          { type: "submit", content: "搜索", status: "primary" },
          { type: "reset", content: "重置" },
        ],
      },
    },
  ],
});

const formEvents: VxeFormListeners = {
  submit(form) {
    const { data } = form;
    if (data.tableName) {
      queryParams.value.whereStr = JSON.stringify(data);
    }
    initData();
    console.log("form submit", form);
  },
  reset() {
    console.log(defaultParams, "defaultParams");
    queryParams.value = { ...defaultParams };
    initData();
  },
};

const defaultParams = {
  currentPage: 1,
  totalCount: 0,
  totalPage: 0,
  isNext: false,
  isLast: false,
  indexCount: 0,
  everyCount: 10,
  whereStr: "{}",
  // whereStr: '{"tableName":"TB_ACC"}',
  // TB_CST_PERS
  indexList: [],
  serviceName: "importFileServiceTwoImpl",
  conditionList: [],
  paramJson: "{}",
};

const queryParams = ref<any>(cloneDeep(defaultParams));

// 弹窗相关
const showModal = ref(false);
const modalTitle = ref("");
const defaultModalParams = {
  currentPage: 1,
  totalCount: 0,
  totalPage: 0,
  isNext: false,
  isLast: false,
  indexCount: 0,
  everyCount: 50,
  whereStr: "{}",
  indexList: [],
  serviceName: "multipleFileImportService",
  resultTableName: "",
  conditionList: [],
  paramJson: "{}",
};
const defaultErrModalParams = {
  currentPage: 1,
  totalCount: 0,
  totalPage: 0,
  isNext: false,
  isLast: false,
  indexCount: 0,
  everyCount: 10,
  whereStr: "{}",
  indexList: [],
  paramJson: "",
};
const columnsForErr = [
  {
    title: "表名",
    key: "TABLE_NAME",
    overflow: true,
    align: "center",
    width: 200,
  },
  {
    title: "表描述",
    key: "TABLE_DESC",
    align: "center",
  },
  {
    title: "字段名",
    key: "COLUMN_NAME",
    align: "center",
  },
  {
    title: "字段描述",
    overflow: true,
    key: "COLUMN_DESC",
    align: "center",
    width: 100,
  },
  {
    title: "错误数量",
    key: "ERR_LINE_TOTAL",
    align: "center",
    width: 200,
  },
  {
    title: "错误原因",
    key: "ERR_REASON",
    width: 300,
    overflow: true,
    align: "center",
  },
];
const queryErrModalParams = ref<any>(cloneDeep(defaultErrModalParams));
const queryModalParams = ref<any>(cloneDeep(defaultModalParams));
const tableModalData = ref<RowVO[]>([]);
const modalLoading = ref(false);
let modalColumns: any[] = [];

const openModal = async (row) => {
  await initModalData(row);
  modalTitle.value = `数据预览（${queryModalParams.value.resultTableName}）`;
  showModal.value = true;
};

const openErrInfo = async (row) => {
  await initErrModalData(row);
  modalTitle.value = "错误信息汇总";
  showModal.value = true;
};

const hideSubEvent = () => {
  queryModalParams.value = cloneDeep(defaultModalParams);
};

const openConfirm = (row) => {
  ElMessageBox.confirm("确认要删除这个记录吗？", "操作确认", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  })
    .then(() => {
      ImportWorkAPI.delFromDataImportFile(row.fileId).then((res) => {
        if (res.state) {
          initData();
          ElMessage.success("删除成功");
        }
      });
    })
    .catch(() => {
      ElMessage({
        type: "info",
        message: "取消删除",
      });
    });
};

const initModalData = (row = null) => {
  if (row?.tableName) {
    queryModalParams.value.resultTableName = row.tableName;
  }

  modalLoading.value = true;
  ImportWorkAPI.getPage(queryModalParams.value)
    .then((resData) => {
      if (resData) {
        const { resObj, resMap } = resData;
        if (resMap?.tableCol) {
          modalColumns = resMap?.tableCol?.map((col) => {
            return {
              // ...col,
              title: col.columnDesc,
              key: col.columnName,
              align: "center",
              width: 100,
            };
          });
          tableModalData.value = convertDataJsonForTable(resObj?.dataJson);
          queryModalParams.value.totalCount = resObj?.totalCount;
          queryModalParams.value.totalPage = resObj?.totalPage;
          queryModalParams.value.everyCount = resObj?.everyCount;
        }
      }
    })
    .finally(() => {
      modalLoading.value = false;
    });
};

const initErrModalData = (row = null) => {
  if (row?.fileId) {
    queryErrModalParams.value.paramJson = JSON.stringify({ fileId: row.fileId });
  }

  modalLoading.value = true;
  ImportWorkAPI.getFileErrList(queryErrModalParams.value)
    .then((resData) => {
      if (resData.data) {
        const { dataList, totalCount, totalPage, everyCount } = resData.data;
        modalColumns = columnsForErr;
        tableModalData.value = dataList ?? [];
        queryErrModalParams.value.totalCount = totalCount;
        queryErrModalParams.value.totalPage = totalPage;
        queryErrModalParams.value.everyCount = everyCount;
      }
    })
    .finally(() => {
      modalLoading.value = false;
    });
};
function pageChange1(page) {
  const { currentPage, pageSize } = page;
  queryParams.value.indexCount = pageSize * currentPage - pageSize;
  initData();
}

function pageChange2(page) {
  const { currentPage, pageSize } = page;
  queryModalParams.value.indexCount = pageSize * currentPage - pageSize;
  initModalData();
}

// 导入相关
const showImportModal = ref(false);
const showImport = () => {
  showImportModal.value = true;
};
const handleStepChange = (step: number) => {
  console.log(`当前步骤：${step}`);
};
const updateVisible = (value) => {
  showImportModal.value = value;
  !value && initData();
};

const initData = () => {
  ImportWorkAPI.getPage(queryParams.value).then((resData) => {
    if (resData?.resObj) {
      const { totalCount, totalPage, everyCount, dataJson } = resData.resObj;
      tableData.value = convertDataJsonForTable(dataJson);
      queryParams.value.totalCount = totalCount;
      queryParams.value.totalPage = totalPage;
      queryParams.value.everyCount = everyCount;
    }
  });
};

onMounted(() => {
  initData();
});
</script>
