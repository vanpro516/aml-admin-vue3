<template>
  <div class="crud-container">
    <vxe-card shadow class="left-card">
      <template #title>
        <div class="flex-y-center">
          <el-icon size="16"><FolderOpened /></el-icon>
          <span class="ml-1">检测进度</span>
        </div>
      </template>
      <div class="">
        <vxe-image class="mt-[40px]" :src="IMG" :height="200" />
        <p>
          扫描进度
          <span class="text-[24px]">{{ process }}%</span>
        </p>
        <el-progress
          class="w-[60%] mx-a"
          :show-text="false"
          :color="customColor"
          :stroke-width="15"
          :percentage="process"
        />
        <p>
          共检测
          <span class="text-[20px]">{{ checkInfo?.total ?? 0 }}</span>
          项 , 已检查
          <span class="text-[20px]">{{ checkInfo?.checked ?? 0 }}</span>
          项
        </p>
        <el-button
          class="w-[130px] mt-[30px]"
          size="large"
          :type="disabled ? '' : 'primary'"
          :disabled="disabled"
          @click="resetCheckPost"
        >
          重新检测
        </el-button>
        <br />
        <el-button
          class="w-[130px] mt-[30px]"
          size="large"
          :type="disabled ? '' : 'warning'"
          :disabled="disabled"
          @click="downloadReport"
        >
          下载报告
        </el-button>
        <p>提交检测时间：{{ checkInfo?.checkDate ?? "" }}</p>
        <el-button class="w-[130px] mt-[30px]" size="large" type="warning" @click="showDialog">
          下载历史报告
        </el-button>
      </div>

      <el-dialog v-model="batchNoDialogVisible" title="选择批次号进行下载" width="300">
        <vxe-select
          v-model="batchNo"
          class="!w-full"
          placeholder="批次号"
          :options="allBatchNoList"
        ></vxe-select>
        <template #footer>
          <div class="dialog-footer">
            <el-button @click="batchNoDialogVisible = false">取消</el-button>
            <el-button type="primary" @click="downloadReport">确定</el-button>
          </div>
        </template>
      </el-dialog>
    </vxe-card>
    <vxe-card shadow class="right-card">
      <template #title>
        <div>
          <span>检测结果</span>
        </div>
      </template>
      <div class="">
        <el-tree :data="treeData" :props="props" :height="208" default-expand-all>
          <template #default="{ node, data }">
            <div v-if="data.treeType === '1'" class="w-full pr-4">
              <div class="flex items-center">
                <!-- load-loop -->
                <el-icon size="16" class="mr-1" :class="{ 'load-loop': isLoopStatus(data.status) }">
                  <WarningFilled v-if="data.rerultCount > 0" color="#ff9900" />
                  <CircleCheckFilled
                    v-else-if="
                      [
                        Status.EXECUTION_COMPLETED,
                        Status.EXECUTION_COMPLETED_10,
                        Status.EXECUTION_COMPLETED_11,
                      ].includes(data.status)
                    "
                    color="#28c18d"
                  />
                  <CircleCloseFilled v-else-if="data.status === '9'" color="#db2828" />
                  <img v-else src="../../assets/imgs/ic_reset.png" alt="ic_reset" />
                </el-icon>
                <span class="!truncate" :title="node.label">{{ node.label }}</span>
                <!-- <span class="text-blue">{{ statusMap[data.status] }}--{{ data.status }}</span> -->
              </div>
              <div class="flex justify-end w-full">
                <!-- Status.EXECUTION_EXCEPTION 是程序语句出错 正常不会是这个状态 -->
                <template
                  v-if="
                    [
                      Status.EXECUTION_COMPLETED,
                      Status.EXECUTION_COMPLETED_10,
                      Status.EXECUTION_COMPLETED_11,
                    ].includes(data.status)
                  "
                >
                  <p>
                    检查条数：
                    <span class="ml-[10px] mr-[15px]">
                      {{ data.checkCount > 0 ? data.checkCount : 0 }}
                    </span>
                  </p>
                  <p>
                    违规条数：
                    <span class="text-red ml-[10px] mr-[15px]">
                      {{ data.rerultCount > 0 ? data.rerultCount : 0 }}
                    </span>
                  </p>
                  <p>
                    违规比例：
                    <span class="text-red ml-[10px] mr-[15px]">{{ data.percentString }}</span>
                  </p>
                  <el-button size="small" @click="setModalDetail(data)">详情</el-button>
                </template>
              </div>
            </div>
            <span v-else class="!truncate" :title="node.label">
              {{ node.label }}
            </span>
          </template>
        </el-tree>
        <DetailModal
          v-model.sync="showModal"
          :info="modalCheckInfo"
          title="检测结果"
          @update:visible="updateVisible"
        />
      </div>
    </vxe-card>
  </div>
</template>
<script lang="ts" setup>
import { ref } from "vue";
import IMG from "@//assets/imgs/rock.png";
import ImportModelAPI from "@/api/model";
import { findNodesByType, saveFile } from "@/utils";
import { Status } from "@/utils/constant";
import DetailModal from "@/views/work/components/DetailModal.vue";
import PageResultAPI from "@/api/result";
import { dayjs } from "element-plus";

const proc = ref();
const disabled = ref(true);
const customColor = "#3b6cde";
const checkInfo = ref({});
const batchNo = ref("");
const batchNoDialogVisible = ref(false);
const allBatchNoList = ref([]);
const modalCheckInfo = ref({}); // 弹窗数据
const treeData = ref([]);
const heightNodeClass = ({ treeType }, node) => (treeType === "1" ? "node1" : "");
const props = {
  value: "treeId",
  label: "ruleName",
  class: heightNodeClass,
  children: "children",
};
const showModal = ref(false);
const process = computed(() => {
  const p = Math.round((checkInfo.value?.checked / checkInfo.value?.total) * 100);
  if (p == 100) {
    disabled.value = false;
  }
  return checkInfo.value ? p : 0;
});

function showDialog() {
  PageResultAPI.getAllBatchNo().then((res) => {
    allBatchNoList.value = (res?.resObj || []).map((batch) => ({
      value: batch.AUTO_CHECK_ID,
      label: batch.AUTO_CHECK_ID,
    }));
    batchNoDialogVisible.value = true;
  });
}

function downloadReport() {
  const fileName = `${batchNo.value}检测报告_${dayjs().format("YYYY-MM-DD")}.pdf`;
  PageResultAPI.downloadReport({ batchNo: batchNo.value }).then((response) => {
    const fileData = response.data;
    const fileType = "application/pdf";
    saveFile(fileData, fileName, fileType);
    batchNoDialogVisible.value = false;
    ElMessage.success("检测报告下载成功");
  });
}

function init() {
  ImportModelAPI.getModelTreelist().then((res) => {
    if (res.state && res.resMap) {
      checkInfo.value.total = Number(res.resMap.total);
      checkInfo.value.checked = Number(res.resMap.checked);
    }
    if (res.state && res.resList && res.resList.length) {
      checkInfo.value.checkDate = res.resList[0].submitTime;
      batchNo.value = res.resList[0].autoCheckId;
      treeData.value = res.resList;
    }
  });
}

function setModalDetail(row) {
  modalCheckInfo.value = row;
  showModal.value = true;
}

function updateVisible(value: boolean) {
  showModal.value = value;
}

function resetCheckPost() {
  ElMessageBox.confirm("您确定要重新检测吗？", "提示", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
    lockScroll: false,
  }).then(() => {
    const ruleRunIdList = findNodesByType(treeData.value, "treeType", "1");
    const modelIds = ruleRunIdList.map((e) => e.ruleRunId);
    ImportModelAPI.resetCheck(modelIds).then((res) => {
      if (res.state) {
        checkInfo.value.checked = 0;
        checkInfo.value.date = new Date();
        init();
        getProcState();
      } else {
        ElMessage.error(res.resMsg);
      }
    });
  });
}

function getProcState() {
  proc.value = setInterval(() => {
    if (checkInfo.value.checked < checkInfo.value.total) {
      init();
    } else {
      clearInterval(proc.value!);
    }
  }, 1000);
}

function isLoopStatus(status) {
  return !["8", "9", "10", "11"].includes(status);
}

onMounted(() => {
  if (proc.value) {
    clearInterval(proc.value!);
  }
  init();
  getProcState();
});

onUnmounted(() => {
  clearInterval(proc.value!);
});
</script>

<style lang="scss" scoped>
.crud-container {
  @apply flex space-x-2;
}
.left-card {
  @apply h-full min-w-[310px] max-w-[310px] flex-x-center text-center;
}
.right-card {
  @apply h-full flex-1;
}
:deep(.node1 .el-tree-node__content) {
  height: 60px !important;
}
@keyframes loop {
  0% {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  100% {
    transform: rotate(1turn);
  }
}
.load-loop {
  /* width: 16px;
  height: 16px;
  margin-right: 6px; */

  animation: loop 1s linear infinite;
}
</style>
