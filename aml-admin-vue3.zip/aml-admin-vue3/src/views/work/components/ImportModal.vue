<template>
  <vxe-modal v-model="show" resize :title="`导入文件`" width="800" @hide="hideSubEvent">
    <div class="step-nav relative">
      <div
        v-for="step in steps"
        :key="step.index"
        class="flex step-divider"
        :class="{ active: currentStep === step.index || currentStep > step.index }"
      >
        <div class="flex-center">
          <el-icon>
            <component :is="step.icon" />
          </el-icon>
          <p>{{ step.label }}</p>
        </div>
      </div>
    </div>

    <!-- 内容区 -->
    <div class="step-content">
      <el-upload
        v-if="currentStep === 0"
        v-model:file-list="importFileList"
        class="uploadBox"
        :before-upload="beforeUpload"
        :http-request="handleUpload"
        :on-remove="handleFileRemove"
        :on-progress="handProgress"
        :on-success="handleSuccess"
        :on-error="handleError"
        drag
        multiple
      >
        <el-icon class="el-icon--upload"><upload-filled /></el-icon>
        <div class="el-upload__text">点击或拖动文件到此处上传文件</div>
        <!-- <template #tip>
          <div class="el-upload__tip">jpg/png files with a size less than 500kb</div>
        </template> -->
      </el-upload>

      <vxe-table
        v-if="currentStep >= 1"
        border
        height="390px"
        :row-config="{ keyField: 'name' }"
        :data="importFileList"
      >
        <vxe-column field="name" title="文件名称"></vxe-column>
        <vxe-column field="tableName" title="目标表名" width="150">
          <template v-if="currentStep === 1" #default="{ row }">
            <vxe-select v-model="row.tableName">
              <vxe-option
                v-for="target in targetList"
                :key="target._X_OPTION_KEY"
                :value="target.tableName"
                :label="`${target.tableName}(${target.tableDesc})`"
              ></vxe-option>
            </vxe-select>
          </template>
        </vxe-column>
        <vxe-column field="delimitField" title="分隔符" width="100">
          <template v-if="currentStep === 1" #default="{ row }">
            <vxe-input v-model="row.delimitField"></vxe-input>
          </template>
        </vxe-column>
        <vxe-column field="ifTitle" title="是否存在标题行" width="120">
          <template #default="{ row }">
            <vxe-switch
              v-if="currentStep === 1"
              v-model="row.ifTitle"
              :open-value="1"
              :close-value="0"
            ></vxe-switch>
            <span v-else>{{ row.ifTitle === 1 ? "是" : "否" }}</span>
          </template>
        </vxe-column>
        <vxe-column field="status" title="是否清数据" width="120">
          <template #default="{ row }">
            <vxe-select
              v-if="currentStep === 1"
              v-model="row.status"
              :options="isClearOptions"
            ></vxe-select>
            <span v-else>{{ findLabelByValue(isClearOptions, row.status) }}</span>
          </template>
        </vxe-column>
      </vxe-table>
    </div>

    <div class="flex-center">
      <vxe-button v-if="currentStep > 0" status="primary" @click="prevStep">上一步</vxe-button>
      <vxe-button v-if="currentStep < 2" status="primary" @click="nextStep">下一步</vxe-button>
      <vxe-button v-if="currentStep === 2" status="success" @click="saveStep">提交</vxe-button>
    </div>
  </vxe-modal>
</template>

<script setup lang="ts">
import { ref, defineProps, defineEmits, computed } from "vue";
import { DocumentAdd, DataAnalysis, Search } from "@element-plus/icons-vue";
import {
  UploadRawFile,
  UploadUserFile,
  UploadProgressEvent,
  UploadRequestOptions,
} from "element-plus";
import ImportWorkAPI from "@/api/work";
import { findLabelByValue } from "@/utils";

interface ColumnConfig {
  key: string;
  title: string;
  overflow?: boolean;
  width?: number;
}

const props = defineProps({
  title: {
    type: String,
    default: "弹窗标题",
  },
  width: {
    type: Number,
    default: 600,
  },
  height: {
    type: Number,
    default: 400,
  },
  visible: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(["confirm", "cancel", "update:visible", "stepChange"]);

const show = computed({
  get: () => props.visible,
  set: (value) => emit("update:visible", value),
});

const isClearOptions = [
  { label: "不清数据", value: "1" },
  { label: "清除数据", value: "0" },
];

const steps = ref([
  { index: 0, icon: DocumentAdd, label: "选择文件", color: "#1890ff", active: false },
  { index: 1, icon: DataAnalysis, label: "匹配表名", color: "#666", active: false },
  { index: 2, icon: Search, label: "预览结果", color: "#666", active: false },
]);

function prevStep() {
  if (currentStep.value > 0) {
    currentStep.value--;
    emit("stepChange", currentStep.value);
  }
}

function nextStep() {
  if (!hasFile.value) {
    ElMessage.warning("请上传文件");
    return false;
  }
  if (currentStep.value < steps.value.length - 1) {
    currentStep.value++;
    emit("stepChange", currentStep.value);
    if (currentStep.value === 1) {
      ImportWorkAPI.getTargetTab().then((res) => {
        targetList.value = res?.resList || [];
        importFileList.value.forEach((x) => {
          if (!x.hasOwnProperty("tableName")) {
            x["tableName"] = x.name.substring(0, x.name.lastIndexOf(".")).toUpperCase();
          }
          if (!x.hasOwnProperty("ifTitle")) {
            x["ifTitle"] = 0;
          }
          if (!x.hasOwnProperty("delimitField")) {
            x["delimitField"] = "|";
          }
          if (!x.hasOwnProperty("oriPath")) {
            x["oriPath"] = x.response.resMap["filePath"] || "";
          }
          if (!x.hasOwnProperty("oriSize")) {
            x["oriSize"] = x.size;
          }
        });
      });
    }

    console.log(importFileList.value, " importFileList.value");
  }
}

function saveStep() {
  ImportWorkAPI.saveImportFile(importFileList.value).then((res) => {
    if (res.state) {
      ElMessage.success("本地导入成功");
      emit("update:visible", false);
    }
  });
}

function hideSubEvent() {
  currentStep.value = 0;
  targetList.value = [];
  importFileList.value = [];
}

// ————导入相关————
const currentStep = ref(0);
const targetList = ref([]);
const importFileList = ref<UploadUserFile[]>([]);
const hasFile = computed(() => {
  return importFileList.value && importFileList.value.length > 0;
});

function beforeUpload(file) {
  console.log(file);
  if (file.size === 0) {
    ElMessage.error("文件为空");
    return false;
  }
  if (file.size > 3 * 1024 * 1024 * 1024) {
    ElMessageBox.alert("文件超过3g,请选择从服务器上传", "警告", {
      type: "warning",
    });
    return false;
  } else {
    return true;
  }
}

/*
 * 上传文件
 */
function handleUpload(options: UploadRequestOptions) {
  return new Promise((resolve, reject) => {
    const file = options.file;
    const formData = new FormData();
    formData.append("file", file);

    ImportWorkAPI.upload(formData)
      .then((data) => {
        resolve(data);
      })
      .catch((error) => {
        reject(error);
      });
  });
}

function handleFileRemove(file, fileList) {
  const filePath = file.response.resMap["filePath"] || "";
  ImportWorkAPI.removeImportFile({ filePath }).then((res) => {
    if (res.state) {
      ElMessage.info(res.resMsg);
    } else {
      ElMessage.error(res.resMsg);
    }
  });
}

function handProgress() {
  // this.complete = false;
}

function handleSuccess(response, file, fileList) {
  console.log(response, file, fileList);

  if (response.state) {
    fileList.forEach((x) => {
      x.status = "1";
    });
  } else {
    ElMessage.error(response.resMsg);
    return false;
  }
}

function handleError(error, file, fileList) {
  ElMessage.error("文件上传失败".concat(error));
  return false;
}
</script>

<style lang="scss" scoped>
.step-nav {
  display: flex;
  justify-content: space-between;
}

.step-nav div {
  height: 50px;
  line-height: 50px;
  /* width: 100%; */
  border-radius: 4px;
  cursor: pointer;
}

.step-nav .active {
  color: #1890ff;
}

.step-nav i {
  font-size: 18px;
  margin-right: 8px;
}

.step-content {
  height: 400px;
  width: 100%;
}
.uploadBox {
  width: 60%;
  height: 100%;
  margin: 0 auto;
  .el-icon--upload {
    color: #3499ff;
  }
  :deep(.el-upload) {
    margin-top: 50px;
  }
}

/* 最后一个步骤不显示连接线 */
.step-divider:not(:last-child)::after {
  content: "";
  position: absolute;
  /* left: 100px; */
  top: 25px;
  width: 230px;
  height: 2px;
  margin-left: 100px;
  background-color: #e0e0e0;
  /* background-color: red; */
}
</style>
