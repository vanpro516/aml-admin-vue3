<template>
  <vxe-modal v-model="show" resize :title="title" width="90%">
    <el-card shadow="hover" :body-style="bodyStyle">
      <template #header>
        <div class="font-bold">{{ checkResult.ruleName }}</div>
      </template>
      <el-row class="rows">
        <el-col :span="4">
          <div class="grid-content grid-content-light">检查条数</div>
        </el-col>
        <el-col :span="4">
          <div class="grid-content">{{ checkResult.checkCount }}</div>
        </el-col>
        <el-col :span="4">
          <div class="grid-content grid-content-light">违规条数</div>
        </el-col>
        <el-col :span="4">
          <div class="grid-content text-red">{{ checkResult.rerultCount }}</div>
        </el-col>
        <el-col :span="4">
          <div class="grid-content grid-content-light">违规比例</div>
        </el-col>
        <el-col :span="4">
          <div class="grid-content text-red">{{ checkResult.percentString }}</div>
        </el-col>
      </el-row>
    </el-card>

    <el-card shadow="hover" :body-style="bodyStyle" class="mt-[10px]">
      <template #header>
        <div class="font-bold flex justify-between">
          <span>违规数据</span>
          <el-button size="small" type="primary" @click="showSubModal = true">数据筛选</el-button>
        </div>
      </template>
      <vxe-table
        border
        height="390px"
        :row-config="{ keyField: 'columnSeq' }"
        :data="tableData"
        :loading="loading"
      >
        <vxe-column
          v-for="item in columnsRow"
          :key="item.key"
          :field="item.key"
          :title="item.title"
          :show-overflow="item.overflow"
          :width="item.width ? item.width : ''"
        ></vxe-column>
      </vxe-table>
      <vxe-pager
        v-model:current-page="queryParams.currentPage"
        v-model:page-size="queryParams.everyCount"
        :total="queryParams.totalCount"
        :layouts="tableLayouts"
        @page-change="pageChange"
      />
    </el-card>

    <!-- 数据筛选弹窗 -->
    <vxe-modal v-model="showSubModal" resize :title="'筛选条件'" width="50%">
      <div class="filter-container">
        <div class="button-group mb-[10px]">
          <vxe-button @click="validEvent">校验变动数据</vxe-button>
          <vxe-button @click="fullValidEvent">校验全量数据</vxe-button>
          <el-button type="primary" round @click="addCondition">添加筛选条件</el-button>
          <el-button round @click="clearConditions">清除筛选条件</el-button>
          <el-button type="primary" style="float: right" round @click="handleQuery">查询</el-button>
        </div>
        <vxe-table border height="390px" :row-config="{ keyField: 'id' }" :data="conditionList">
          <vxe-column field="columnName" title="条件名称" min-width="180">
            <template #default="{ row }">
              <vxe-select
                v-model="row.columnName"
                style="width: 100%"
                placeholder="选择条件名称"
                :options="isClearOptions"
              ></vxe-select>
            </template>
          </vxe-column>
          <vxe-column field="operator" title="操作符" min-width="180">
            <template #default="{ row }">
              <vxe-select
                v-model="row.operator"
                placeholder="选择操作符"
                style="width: 100%"
                :options="isClearOptions"
              ></vxe-select>
            </template>
          </vxe-column>
          <vxe-column field="columnValue" title="条件值" min-width="180">
            <!-- 日期范围或者输入框 -->
            <template #default="{ row }">
              <vxe-select
                v-model="row.columnValue"
                placeholder="选择条件名称"
                :options="isClearOptions"
              ></vxe-select>
            </template>
          </vxe-column>
          <vxe-column field="action" title="操作" min-width="70">
            <template #default="{ row }">
              <el-button type="primary" @click="clearConditions(row)">移除</el-button>
            </template>
          </vxe-column>
        </vxe-table>
      </div>
    </vxe-modal>
  </vxe-modal>
</template>

<script setup lang="ts">
import { ref, defineProps, defineEmits, computed } from "vue";
import { SizeEnum } from "@/enums/SizeEnum";
import { DocumentAdd, DataAnalysis, Search } from "@element-plus/icons-vue";
import {
  UploadRawFile,
  UploadUserFile,
  UploadProgressEvent,
  UploadRequestOptions,
} from "element-plus";
import ImportWorkAPI from "@/api/work";
import { convertDataJsonForTable } from "@/utils";
import { tableLayouts } from "@/utils/constant";

interface ColumnConfig {
  key: string;
  title: string;
  overflow?: boolean;
  width?: number;
}
const bodyStyle = { padding: "16px" };
const props = defineProps({
  title: {
    type: String,
    default: "弹窗标题",
  },
  width: {
    type: Number,
    default: 600,
  },
  height: {
    type: Number,
    default: 400,
  },
  visible: {
    type: Boolean,
    default: false,
  },
  info: {
    type: Object,
    default: false,
  },
});

const emit = defineEmits(["update:visible"]);

const show = computed({
  get: () => props.visible,
  set: (value) => emit("update:visible", value),
});

const checkResult = computed(() => {
  return props.info;
});
const queryParams = ref({
  currentPage: 1,
  totalCount: 0,
  totalPage: 0,
  isNext: false,
  isLast: false,
  indexCount: 0,
  everyCount: 10,
  whereStr: "{}",
  indexList: [],
  serviceName: "ruleResultServicesImpl",
  resultTableName: "",
  conditionList: [],
  paramJson: "{}",
});
const columnsRow = ref([]);
const tableData = ref([]);
const batchid = ref("");
const loading = ref(false);
const showSubModal = ref(false);
const isClearOptions = [
  { label: "不清数据", value: "Women" },
  { label: "清除数据", value: "Man" },
];
const getColumnNameListByTableName = () => {
  ImportWorkAPI.getTableInfo({
    tableName: checkResult.value.resultTable,
  }).then((res) => {
    columnsRow.value = (res?.resList || []).map((ele) => {
      const isShort = ele.columnName === "procstate";
      return {
        title: ele.columnDesc,
        slot: isShort ? ele.columnName : undefined,
        fixed: isShort ? "right" : undefined,
        key: ele.columnName,
        align: "center",
        width: isShort ? 120 : 180,
      };
    });
  });
};

const getData = () => {
  tableData.value = [];
  if (batchid.value) {
    queryParams.value.paramJson = JSON.stringify({ batchid: batchid.value });
  }
  ImportWorkAPI.getPage(queryParams.value).then((resData) => {
    if (resData?.resObj) {
      const { totalCount, totalPage, everyCount, dataJson } = resData.resObj;
      tableData.value = convertDataJsonForTable(dataJson);
      queryParams.value.totalCount = totalCount;
      queryParams.value.totalPage = totalPage;
      queryParams.value.everyCount = everyCount;
    }
  });
};

const pageChange = (page) => {
  const { currentPage, pageSize } = page;
  queryParams.value.indexCount = pageSize * currentPage - pageSize;
  getData();
};

// 筛选相关
interface RowVO {
  id: number;
  /** 条件名称 */
  columnName: string;
  /** 条件名称 */
  operator: string;
  sex: string;
  age: number;
  address: string;
}
const conditionList = ref<RowVO[]>([]);
const conditionItem = {};
const addCondition = () => {};
const clearConditions = (row = null) => {};
const handleQuery = () => {};
watch(
  () => props.info,
  (newVal) => {
    if (newVal.treeId) {
      queryParams.value.resultTableName = checkResult.value.resultTable;
      batchid.value = checkResult.value.autoCheckId;
      getColumnNameListByTableName();
      getData();
    }
  },
  { immediate: true }
);
</script>

<style lang="scss" scoped>
.grid-content,
.grid-content-light {
  background-color: #ffffff;
  border: 1px solid #e8eaec;
  height: 48px;
  line-height: 48px;
  padding: 0 10px;
}
.grid-content-light {
  background-color: #f8f8f9;
}
.grid-content,
.grid-content-light {
  border-right-width: 0;
}
.rows:last-child {
  border-right-width: 1px;
  border-color: #e8eaec;
}
</style>
