<template>
  <div class="crud-container">
    <vxe-form
      v-bind="formOptions"
      class="mb-[10px]"
      :data="formData"
      @submit="submit"
      @reset="reset"
    ></vxe-form>

    <vxe-toolbar class="my-[10px]">
      <template #buttons>
        <vxe-button class="ml-[10px]" status="primary" @click="addEvent">新增租户</vxe-button>
        <vxe-button class="ml-[10px]" @click="batchDelEvent">批量删除</vxe-button>
      </template>
    </vxe-toolbar>

    <vxe-table
      ref="tableRef"
      :data="tableData"
      :size="SizeEnum.MEDIUM"
      :align="AlignEnum.CENTER"
      height="450"
    >
      <vxe-column
        v-for="item in columns"
        :key="item.key"
        :field="item.key"
        :fixed="item.fixed"
        :title="item.title"
        :show-overflow="item.overflow"
        :width="item.width ? item.width : ''"
      >
        <template v-if="item.slot === 'action'" #default="{ row }">
          <el-button type="primary" link @click="showEdit(row)">编辑</el-button>
          <el-button type="primary" link @click="delConfirm(row)">删除</el-button>
          <el-button type="primary" link @click="showUsers(row)">用户</el-button>
        </template>
      </vxe-column>
    </vxe-table>
    <vxe-pager
      v-model:current-page="queryParams.pageNum"
      v-model:page-size="queryParams.pageSize"
      :total="queryParams.totalCount"
      :layouts="tableLayouts"
      @page-change="pageChange1"
    />

    <vxe-modal
      v-model="showModal"
      resize
      destroy-on-close
      showFooter
      title="新增模型"
      width="800px"
    >
      <vxe-form ref="formRef" v-bind="modalFormOptions" :data="modalFormData"></vxe-form>

      <template #footer>
        <vxe-button content="取消" @click="hideSubEvent"></vxe-button>
        <vxe-button status="primary" content="确认" @click="confirmEvent"></vxe-button>
      </template>
    </vxe-modal>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { SizeEnum } from "@/enums/SizeEnum";
import { AlignEnum } from "@/enums/LayoutEnum";
import { convertDataJsonForTable, filterObject, guid } from "@/utils/index";
import type { VxeFormProps, VxeFormInstance } from "vxe-pc-ui";
import { cloneDeep } from "lodash-es";
import { tableLayouts, tradeList, companySizeList } from "@/utils/constant";
import SysTenantAPI from "@/api/system/tenant";
import { TableInstance } from "element-plus";

interface RowVO {
  id: number;
  name: string;
  role: string;
  sex: string;
  age: number;
  address: string;
}

const tableData = ref<RowVO[]>([]);
const columns = [
  {
    title: "租户名称",
    key: "name",
    align: "center",
    width: 200,
    fixed: "left",
  },
  {
    title: "租户编号(ID)",
    key: "id",
    align: "center",
    width: 180,
  },
  {
    title: "所属行业",
    key: "trade_dictText",
    align: "center",
    // width: 150,
    // overflow: true,
  },
  {
    title: "公司规模",
    key: "companySize_dictText",
    width: 100,
    align: "center",
  },
  {
    title: "门牌号",
    key: "houseNumber",
    align: "center",
    width: 100,
  },
  // {
  //   title: "职级",
  //   key: "position_dictText",
  //   align: "center",
  //   width: 150,
  // },
  // {
  //   title: "部门",
  //   key: "department_dictText",
  //   align: "center",
  //   width: 150,
  // },
  {
    title: "创建者(拥有者)",
    key: "createBy_dictText",
    align: "center",
    width: 150,
  },
  {
    title: "状态",
    key: "status_dictText",
    align: "center",
    width: 100,
  },
  {
    title: "操作",
    align: "center",
    slot: "action",
    fixed: "right",
    width: 150,
  },
];
interface FormDataVO {
  name: string;
  status: string;
}
const defaultData = {
  name: "",
  status: "",
};
const formData = ref<FormDataVO>(cloneDeep(defaultData));
const formOptions = reactive<VxeFormProps>({
  items: [
    {
      field: "name",
      title: "租户名称",
      span: 6,
      itemRender: {
        name: "VxeInput",
        props: { clearable: true, placeholder: "请输入租户名称" },
      },
    },
    {
      field: "status",
      title: "状态",
      span: 6,
      itemRender: {
        name: "VxeSelect",
        props: { clearable: true, placeholder: "请选择状态" },
        options: [
          { value: "1", label: "正常" },
          { value: "0", label: "冻结" },
        ],
      },
    },
    {
      span: 3,
      itemRender: {
        name: "VxeButtonGroup",
        options: [
          { type: "submit", content: "查询", status: "primary" },
          { type: "reset", content: "重置" },
        ],
      },
    },
  ],
});

const submit = () => {
  pageChange1({ currentPage: 1, pageSize: 10 });
};
const reset = () => {
  formData.value = cloneDeep(defaultData);
  submit();
};
const showEdit = (row) => {};
const showUsers = (row) => {};
const delConfirm = (row) => {
  ElMessageBox.confirm("是否确认删除", "操作确认", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  })
    .then(() => {
      SysTenantAPI.deleteTenant({ id: row.id }).then((res) => {
        if (res?.code === 200) {
          ElMessage.success(res.message);
          submit();
        }
      });
    })
    .catch(() => {
      ElMessage({
        type: "info",
        message: "取消删除",
      });
    });
};

const defaultParams = {
  column: "createTime",
  order: "desc",
  pageNo: 1,
  pageSize: 10,
  totalCount: 0,
};
const queryParams = ref<any>(cloneDeep(defaultParams));

// 新增弹窗相关
const showModal = ref(false);
const defaultFormData = {
  status: "1",
};
const modalFormData = ref(cloneDeep(defaultFormData));
const modalFormOptions = reactive<VxeFormProps>({
  titleWidth: 120,
  titleAlign: "right",
  titleColon: true,
  validConfig: { theme: "normal" },
  span: 24,
  rules: {
    name: [{ required: true, message: "请输入租户名称" }],
  },
  items: [
    {
      field: "name",
      title: "租户名称",
      itemRender: { name: "VxeInput", props: { clearable: true, placeholder: "租户名称" } },
    },
    {
      field: "id",
      title: "租户编号(ID)",
      itemRender: { name: "VxeInput", props: { disabled: true } },
      visibleMethod: ({ data }) => {
        return data?.id ? true : false;
      },
    },
    {
      field: "trade",
      title: "所属行业",
      itemRender: {
        name: "VxeSelect",
        props: { clearable: true },
        options: tradeList,
      },
    },
    {
      field: "companySize",
      title: "公司规模",
      itemRender: {
        name: "VxeSelect",
        props: { clearable: true },
        options: companySizeList,
      },
    },
    {
      field: "companyAddress",
      title: "公司地址",
      className: "self-center",
      itemRender: {
        name: "VxeTextarea",
        props: {
          autosize: { minRows: 4, maxRows: 8 },
          clearable: true,
          placeholder: "模型描述",
        },
      },
    },
    {
      field: "houseNumber",
      title: "门牌号",
      itemRender: { name: "VxeInput", props: { disabled: true } },
      visibleMethod: ({ data }) => {
        return data?.id ? true : false;
      },
    },
    {
      field: "status",
      title: "状态",
      itemRender: {
        name: "VxeSelect",
        options: [
          { label: "正常", value: "1" },
          { label: "冻结", value: "0" },
        ],
      },
    },
  ],
});
const formRef = ref<VxeFormInstance<FormDataVO>>();
const tableRef = ref<TableInstance>();
const addEvent = () => {
  modalFormData.value = cloneDeep(defaultFormData);
  showModal.value = true;
};
const batchDelEvent = () => {
  // 是否删除选中数据 确认删除
};
const hideSubEvent = () => {
  const $form = formRef.value;
  $form && $form.reset();
  showModal.value = false;
};
const confirmEvent = async () => {
  const $form = formRef.value;
  if ($form) {
    const errMaps = await $form.validate();
    if (!errMaps) {
      SysTenantAPI.addTenant(modalFormData.value).then((res) => {
        if (res?.code === 200) {
          ElMessage.success(res.message);
          hideSubEvent();
        }
      });
    }
  }
};

function pageChange1(page) {
  const { currentPage, pageSize } = page;
  queryParams.value.pageNum = currentPage;
  queryParams.value.pageSize = pageSize;
  initData();
}

const initData = () => {
  SysTenantAPI.getTenantList({ ...queryParams.value, ...formData.value }).then((resData) => {
    const { records = [], current, total, pages } = resData;
    tableData.value = records;
    queryParams.value.totalCount = total;
  });
};

onMounted(() => {
  initData();
});
</script>
