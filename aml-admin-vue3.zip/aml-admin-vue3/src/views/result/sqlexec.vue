<template>
  <div class="crud-container">
    <el-input
      v-model="queryParams.sql"
      class="w-full"
      :autosize="{ minRows: 8, maxRows: 8 }"
      type="textarea"
      placeholder="请输入SQL语句"
    />
    <div class="my-4">
      <vxe-radio-group v-model="queryParams.type" class="mr-4">
        <vxe-radio label="1" content="查询"></vxe-radio>
        <vxe-radio label="2" content="更新"></vxe-radio>
        <vxe-radio label="3" content="创建"></vxe-radio>
        <vxe-radio label="4" content="存储过程"></vxe-radio>
      </vxe-radio-group>
      <el-input
        v-model="queryParams.parm1"
        class="mr-2 !w-[240px]"
        clearable
        placeholder="存储过程参数1"
      />
      <el-input
        v-model="queryParams.parm2"
        class="mr-2 !w-[240px]"
        clearable
        placeholder="存储过程参数2"
      />
      <el-input
        v-model="queryParams.parm3"
        class="mr-2 !w-[240px]"
        clearable
        placeholder="存储过程参数3"
      />
      <el-button type="primary" @click="handleSqlExec">执行</el-button>
    </div>
    <div v-if="tableData && tableData.length && !resMsg">
      <vxe-table
        border
        show-overflow
        :data="tableData"
        :size="SizeEnum.MEDIUM"
        :align="AlignEnum.CENTER"
        height="400"
      >
        <vxe-column
          v-for="item in cols"
          :key="item.key"
          :field="item.key"
          :title="item.title"
          :fixed="item.fixed"
          :width="item.width ? item.width : ''"
        ></vxe-column>
      </vxe-table>
    </div>
    <p v-else>{{ resMsg }}</p>
  </div>
</template>

<script setup lang="ts">
import PageResultAPI from "@/api/result";
import { SizeEnum } from "@/enums/SizeEnum";
import { AlignEnum } from "@/enums/LayoutEnum";

const queryParams = reactive({
  sql: "",
  parm1: "",
  parm2: "",
  parm3: "",
  type: "1",
});
const resMsg = ref("");
const cols = ref([]);
const tableData = ref([]);
const handleSqlExec = async () => {
  try {
    const res = await PageResultAPI.sqlClientQuery(queryParams);
    if (res.state) {
      cols.value = (res?.resObj || []).map((ele) => {
        return {
          title: ele.title,
          key: ele.key,
          align: ele.align,
          fixed: ele.fixed,
          width: ele.width,
        };
      });
      tableData.value = res?.resList || [];
      resMsg.value = "";
    } else {
      resMsg.value = res?.resMsg || "";
      tableData.value = [];
    }
  } catch (err) {
    resMsg.value = JSON.stringify(err);
  }
};
</script>

<style lang="scss" scoped></style>
