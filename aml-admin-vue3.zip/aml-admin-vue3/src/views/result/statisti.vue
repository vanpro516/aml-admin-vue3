<template>
  <div class="crud-container">
    <vxe-form v-bind="formOptions" class="mb-[10px]" v-on="formEvents"></vxe-form>

    <vxe-table :data="tableData" :size="SizeEnum.MEDIUM" :align="AlignEnum.CENTER" height="500">
      <vxe-column
        v-for="item in columns"
        :key="item.key"
        :field="item.key"
        :fixed="item.fixed ? item.fixed : ''"
        :title="item.title"
        :show-overflow="item.overflow"
        :width="item.width ? item.width : ''"
      >
        <template v-if="item.slot === 'action'" #default="{ row }">
          <el-button type="primary" @click="openModal(row)">详细</el-button>
        </template>
      </vxe-column>
    </vxe-table>
    <vxe-pager
      v-model:current-page="queryParams.currentPage"
      v-model:page-size="queryParams.everyCount"
      :total="queryParams.totalCount"
      :layouts="tableLayouts"
      @page-change="pageChange1"
    />

    <vxe-modal
      v-model="showModal"
      resize
      show-maximize
      :title="modalTitle"
      width="1200"
      @hide="hideSubEvent"
    >
      <h2 class="text-[14px] font-bold mb-2">{{ modalRuleName }} : 违规数据</h2>
      <vxe-table
        border
        height="530px"
        :row-config="{ keyField: 'columnSeq' }"
        :data="tableModalData"
        :loading="modalLoading"
        :cell-class-name="setCellClassName"
      >
        <vxe-column
          v-for="item in modalColumns"
          :key="item.key"
          :field="item.key"
          :title="item.title"
          :show-overflow="item.overflow"
          :width="item.width ? item.width : ''"
        ></vxe-column>
      </vxe-table>
      <vxe-pager
        v-model:current-page="queryModalParams.currentPage"
        v-model:page-size="queryModalParams.everyCount"
        :total="queryModalParams.totalCount"
        :layouts="tableLayouts"
        @page-change="pageChange2"
      />
    </vxe-modal>
  </div>
</template>

<script setup lang="tsx">
import { ref } from "vue";
import { SizeEnum } from "@/enums/SizeEnum";
import { AlignEnum } from "@/enums/LayoutEnum";
import ImportWorkAPI from "@/api/work";
import { convertDataJsonForTable, downloadFileByFileId, filterObject } from "@/utils/index";
import type { VxeFormProps, VxeFormListeners } from "vxe-pc-ui";
import { cloneDeep } from "lodash-es";
import { tableLayouts } from "@/utils/constant";
import PageResultAPI from "@/api/result";

interface RowVO {
  id: number;
  name: string;
  role: string;
  sex: string;
  age: number;
  address: string;
}

const tableData = ref<RowVO[]>([]);
const allBatchNoList = ref([]);
const columns = [
  {
    title: "批次号",
    key: "batchId",
    fixed: "left",
    align: "center",
    width: 200,
  },
  {
    title: "模型名称",
    key: "ruleName",
    align: "center",
    overflow: true,
    width: 250,
  },
  {
    title: "机构编号",
    key: "instCode",
    align: "center",
  },
  {
    title: "机构名称",
    key: "instName",
    align: "center",
    overflow: true,
    width: 300,
  },
  {
    title: "预警记录数",
    key: "allCount",
    width: 150,
    overflow: true,
    align: "center",
  },
  {
    title: "操作",
    align: "center",
    slot: "action",
    width: 160,
  },
];
interface FormDataVO {
  instCode: string;
  batchId: string;
}

const formOptions = reactive<VxeFormProps<FormDataVO>>({
  data: {
    instCode: "",
    batchId: "",
  },
  items: [
    {
      field: "batchId",
      title: "批次号",
      span: 5,
      itemRender: {
        name: "VxeSelect",
        options: allBatchNoList,
        props: { clearable: true, placeholder: "批次号" },
      },
    },
    {
      field: "instCode",
      title: "机构编号",
      span: 5,
      itemRender: { name: "VxeInput", props: { clearable: true, placeholder: "机构编号" } },
    },
    {
      span: 3,
      itemRender: {
        name: "VxeButtonGroup",
        options: [
          { type: "submit", content: "查询", status: "primary" },
          { type: "reset", content: "重置" },
        ],
      },
    },
  ],
});

const formEvents: VxeFormListeners = {
  submit() {
    queryParams.value.currentPage = 1;
    pageChange1(queryParams.value);
  },
  reset() {
    queryParams.value = { ...defaultParams };
    initData();
  },
};

const defaultParams = {
  currentPage: 1,
  totalCount: 1,
  totalPage: 1,
  isNext: true,
  isLast: true,
  indexCount: 0,
  everyCount: 10,
  whereStr: "{}",
  serviceName: "modelResultSumarryServiceImpl",
  conditionList: [],
  paramJson: "{}",
};

const queryParams = ref<any>(cloneDeep(defaultParams));

// 弹窗相关
const showModal = ref(false);
const modalTitle = ref("");
const defaultModalParams = {
  currentPage: 1,
  totalCount: 0,
  totalPage: 0,
  isNext: false,
  isLast: false,
  indexCount: 0,
  everyCount: 10,
  whereStr: "{}",
  indexList: [],
  serviceName: "ruleResultServicesImpl",
  resultTableName: "",
  conditionList: [],
  paramJson: "{}",
};
const queryModalParams = ref<any>(cloneDeep(defaultModalParams));
const tableModalData = ref<RowVO[]>([]);
const modalLoading = ref(false);
const modalRuleName = ref("");
let modalColumns = reactive([]);

const openModal = async (row) => {
  await initModalData(row);
  modalTitle.value = `预览结果（${queryModalParams.value.resultTableName}）`;
  modalRuleName.value = row.ruleName;
  showModal.value = true;
};

const hideSubEvent = () => {
  queryModalParams.value = cloneDeep(defaultModalParams);
};

const setCellClassName = ({ column }) => {
  const colorCols = modalColumns.filter((m) => m.color).map((x) => x.key);
  if (colorCols.includes(column.field)) {
    column.className = "demo-table-info-column";
  }
};

const getColumnNameListByTableName = (name) => {
  ImportWorkAPI.getTableInfo({
    tableName: name,
  }).then((res) => {
    modalColumns = (res?.resList || []).map((ele) => {
      const isColorCol = ele.color === "demo-table-info-column";
      return {
        title: ele.columnDesc,
        color: isColorCol ? ele.color : "",
        key: ele.columnName,
        align: "center",
        width: isColorCol ? 120 : 180,
      };
    });
  });
};

const initModalData = (row = null) => {
  if (row?.resultTable) {
    queryModalParams.value.resultTableName = row.resultTable;
    queryModalParams.value.paramJson = JSON.stringify({
      batchid: row.batchId,
      organ: row.instCode,
    });
    getColumnNameListByTableName(row.resultTable);
  }

  modalLoading.value = true;
  tableModalData.value = [];
  ImportWorkAPI.getPage(queryModalParams.value)
    .then((resData) => {
      if (resData.state) {
        const { resObj, resMap } = resData;
        tableModalData.value = convertDataJsonForTable(resObj?.dataJson);
        queryModalParams.value.totalCount = resObj?.totalCount;
        queryModalParams.value.totalPage = resObj?.totalPage;
        queryModalParams.value.everyCount = resObj?.everyCount;
      }
    })
    .finally(() => {
      modalLoading.value = false;
    });
};

function pageChange1(page) {
  const { currentPage, pageSize } = page;
  queryParams.value.indexCount = pageSize * currentPage - pageSize;
  initData();
}

function pageChange2(page) {
  const { currentPage, pageSize } = page;
  queryModalParams.value.indexCount = pageSize * currentPage - pageSize;
  initModalData();
}

const initData = () => {
  queryParams.value.whereStr = JSON.stringify(filterObject(formOptions.data));
  ImportWorkAPI.getPage(queryParams.value).then((resData) => {
    if (resData?.resObj) {
      const { totalCount, totalPage, everyCount, dataJson } = resData.resObj;
      tableData.value = convertDataJsonForTable(dataJson);
      queryParams.value.totalCount = totalCount;
      queryParams.value.totalPage = totalPage;
      queryParams.value.everyCount = everyCount;
    }
  });
};

onMounted(() => {
  PageResultAPI.getBatchIds().then((res) => {
    allBatchNoList.value = (res?.data || []).map((batch) => ({
      value: batch,
      label: batch,
    }));
  });
  initData();
});
</script>

<style lang="scss">
.demo-table-info-column {
  background-color: #ff0000;
  color: #fff;
}
</style>
