<template>
  <div class="crud-container">
    <vxe-form v-bind="formOptions" class="mb-[10px]" v-on="formEvents"></vxe-form>

    <vxe-table :data="tableData" :size="SizeEnum.MEDIUM" :align="AlignEnum.CENTER" height="500">
      <vxe-column
        v-for="item in columns"
        :key="item.key"
        :field="item.key"
        :title="item.title"
        :show-overflow="item.overflow"
        :width="item.width ? item.width : ''"
      >
        <template v-if="item.slot === 'percentString'" #default="{ row }">
          <span
            :style="{
              color: Number(row.percentString.replace('%', '')) >= 5 ? '#fe200c' : '#2b82e4',
            }"
          >
            {{ row.percentString }}
          </span>
        </template>
        <template v-if="item.slot === 'action'" #default="{ row }">
          <div v-if="row.rerultCount > 0">
            <el-button type="primary" @click="openModal(row)">预览</el-button>
            <el-button
              v-if="row.status === statusMap[Status.EXECUTION_COMPLETED]"
              type="danger"
              @click="downloadFileByFileId(row)"
            >
              下载
            </el-button>
          </div>
        </template>
      </vxe-column>
    </vxe-table>
    <vxe-pager
      v-model:current-page="queryParams.currentPage"
      v-model:page-size="queryParams.everyCount"
      :total="queryParams.totalCount"
      :layouts="tableLayouts"
      @page-change="pageChange1"
    />

    <vxe-modal
      v-model="showModal"
      resize
      show-maximize
      :title="modalTitle"
      height="650"
      width="1200"
      @hide="hideSubEvent"
    >
      <vxe-table
        border
        height="530px"
        :row-config="{ keyField: 'columnSeq' }"
        :data="tableModalData"
        :loading="modalLoading"
        :cell-class-name="setCellClassName"
      >
        <vxe-column
          v-for="item in modalColumns"
          :key="item.key"
          :field="item.key"
          :title="item.title"
          :show-overflow="item.overflow"
          :width="item.width ? item.width : ''"
        ></vxe-column>
      </vxe-table>
      <vxe-pager
        v-model:current-page="queryModalParams.currentPage"
        v-model:page-size="queryModalParams.everyCount"
        :total="queryModalParams.totalCount"
        :layouts="tableLayouts"
        @page-change="pageChange2"
      />
    </vxe-modal>
  </div>
</template>

<script setup lang="tsx">
import { ref } from "vue";
import { SizeEnum } from "@/enums/SizeEnum";
import { AlignEnum } from "@/enums/LayoutEnum";
import ImportWorkAPI from "@/api/work";
import { convertDataJsonForTable, downloadFileByFileId, filterObject } from "@/utils/index";
import type { VxeFormProps, VxeFormListeners } from "vxe-pc-ui";
import { cloneDeep } from "lodash-es";
import { percentList, statusList, statusMap, Status, tableLayouts } from "@/utils/constant";

interface RowVO {
  id: number;
  name: string;
  role: string;
  sex: string;
  age: number;
  address: string;
}

const tableData = ref<RowVO[]>([]);
const columns = [
  {
    title: "批次号",
    key: "autoCheckId",
    align: "center",
    width: 80,
  },
  {
    title: "模型名称",
    key: "ruleName",
    align: "center",
    width: 200,
  },
  {
    title: "运行状态",
    key: "status",
    align: "center",
    width: 120,
  },
  {
    title: "完成时间",
    key: "dUpdate",
    align: "center",
    width: 200,
  },
  {
    title: "总记录数",
    key: "checkCount",
    width: 150,
    overflow: true,
    align: "center",
  },
  {
    title: "问题记录",
    key: "rerultCount",
    align: "center",
    width: 120,
  },
  {
    title: "百分比",
    slot: "percentString",
    align: "center",
    width: 150,
  },
  {
    title: "结果路径",
    key: "rerultPath",
    align: "center",
    overflow: true,
  },
  {
    title: "操作",
    align: "center",
    slot: "action",
    width: 160,
  },
];
interface FormDataVO {
  ruleName: string;
  status: string;
  percent: string;
}

const formOptions = reactive<VxeFormProps<FormDataVO>>({
  data: {
    ruleName: "",
    status: undefined,
    percent: undefined,
  },
  items: [
    {
      field: "percent",
      title: "",
      span: 3,
      itemRender: {
        name: "VxeSelect",
        options: percentList,
        props: { clearable: true, placeholder: "比例选择" },
      },
    },
    {
      field: "status",
      title: "",
      span: 3,
      itemRender: {
        name: "VxeSelect",
        options: statusList,
        props: { clearable: true, placeholder: "状态选择" },
      },
    },
    {
      field: "ruleName",
      title: "",
      span: 6,
      itemRender: { name: "VxeInput", props: { clearable: true, placeholder: "模型名称" } },
    },
    {
      span: 2,
      itemRender: {
        name: "VxeButtonGroup",
        options: [{ type: "submit", content: "查询", status: "primary" }],
      },
    },
  ],
});

const formEvents: VxeFormListeners = {
  submit() {
    queryParams.value.currentPage = 1;
    pageChange1(queryParams.value);
  },
  reset() {
    queryParams.value = { ...defaultParams };
    initData();
  },
};

const defaultParams = {
  currentPage: 1,
  totalCount: 0,
  totalPage: 0,
  isNext: false,
  isLast: false,
  indexCount: 0,
  everyCount: 10,
  whereStr: "{}",
  indexList: [],
  serviceName: "ruleRunServiceImpl",
  conditionList: [],
  paramJson: "{}",
};

const queryParams = ref<any>(cloneDeep(defaultParams));

// 弹窗相关
const showModal = ref(false);
const modalTitle = ref("");
const defaultModalParams = {
  currentPage: 1,
  totalCount: 0,
  totalPage: 0,
  isNext: false,
  isLast: false,
  indexCount: 0,
  everyCount: 10,
  whereStr: "{}",
  indexList: [],
  serviceName: "ruleResultServicesImpl",
  resultTableName: "",
  conditionList: [],
  paramJson: "{}",
};
const queryModalParams = ref<any>(cloneDeep(defaultModalParams));
const tableModalData = ref<RowVO[]>([]);
const modalLoading = ref(false);
let modalColumns = reactive([]);

const openModal = async (row) => {
  await initModalData(row);
  modalTitle.value = `预览结果（${queryModalParams.value.resultTableName}）`;
  showModal.value = true;
};

const hideSubEvent = () => {
  queryModalParams.value = cloneDeep(defaultModalParams);
};

const setCellClassName = ({ column }) => {
  const colorCols = modalColumns.filter((m) => m.color).map((x) => x.key);
  if (colorCols.includes(column.field)) {
    column.className = "demo-table-info-column";
  }
};

const getColumnNameListByTableName = (name) => {
  ImportWorkAPI.getTableInfo({
    tableName: name,
  }).then((res) => {
    modalColumns = (res?.resList || []).map((ele) => {
      const isColorCol = ele.color === "demo-table-info-column";
      return {
        title: ele.columnDesc,
        color: isColorCol ? ele.color : "",
        key: ele.columnName,
        align: "center",
        width: isColorCol ? 120 : 180,
      };
    });
  });
};

const initModalData = (row = null) => {
  if (row?.resultTable) {
    queryModalParams.value.resultTableName = row.resultTable;
    queryModalParams.value.paramJson = JSON.stringify({ batchid: row.autoCheckId });
    getColumnNameListByTableName(row.resultTable);
  }

  modalLoading.value = true;
  tableModalData.value = [];
  ImportWorkAPI.getPage(queryModalParams.value)
    .then((resData) => {
      if (resData.state) {
        const { resObj, resMap } = resData;
        tableModalData.value = convertDataJsonForTable(resObj?.dataJson);
        queryModalParams.value.totalCount = resObj?.totalCount;
        queryModalParams.value.totalPage = resObj?.totalPage;
        queryModalParams.value.everyCount = resObj?.everyCount;
      }
    })
    .finally(() => {
      modalLoading.value = false;
    });
};

function pageChange1(page) {
  const { currentPage, pageSize } = page;
  queryParams.value.indexCount = pageSize * currentPage - pageSize;
  initData();
}

function pageChange2(page) {
  const { currentPage, pageSize } = page;
  queryModalParams.value.indexCount = pageSize * currentPage - pageSize;
  initModalData();
}

const initData = () => {
  queryParams.value.whereStr = JSON.stringify(filterObject(formOptions.data));
  ImportWorkAPI.getPage(queryParams.value).then((resData) => {
    if (resData?.resObj) {
      const { totalCount, totalPage, everyCount, dataJson } = resData.resObj;
      tableData.value = convertDataJsonForTable(dataJson);
      queryParams.value.totalCount = totalCount;
      queryParams.value.totalPage = totalPage;
      queryParams.value.everyCount = everyCount;
    }
  });
};

onMounted(() => {
  initData();
});
</script>

<style lang="scss">
.demo-table-info-column {
  background-color: #ff0000;
  color: #fff;
}
</style>
