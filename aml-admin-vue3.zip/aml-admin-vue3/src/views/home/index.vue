<template>
  <div class="crud-container">
    <h1 class="flex-x-center">深圳市法本信息技术股份有限公司</h1>
    <div class="flex-x-center">
      <img src="@/assets/farben.svg" width="100" height="100" />
    </div>
  </div>
</template>

<script setup lang="ts"></script>

<style lang="scss" scoped></style>
