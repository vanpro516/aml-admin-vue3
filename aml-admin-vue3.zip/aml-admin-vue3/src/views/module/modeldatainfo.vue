<template>
  <div class="crud-container">
    <vxe-form v-bind="formOptions" class="mb-[10px]" @submit="submit"></vxe-form>

    <vxe-table :data="tableData" :size="SizeEnum.MEDIUM" :align="AlignEnum.CENTER" height="500">
      <vxe-column type="seq" width="80"></vxe-column>
      <vxe-column
        v-for="item in columns"
        :key="item.key"
        :field="item.key"
        :title="item.title"
        :show-overflow="item.overflow"
        :width="item.width ? item.width : ''"
      >
        <template v-if="item.slot === 'action'" #default="{ row }">
          <el-button type="primary" @click="showDrawerInfo(row)">详情</el-button>
        </template>
      </vxe-column>
    </vxe-table>
    <vxe-pager
      v-model:current-page="queryParams.currentPage"
      v-model:page-size="queryParams.everyCount"
      :total="queryParams.totalCount"
      :layouts="tableLayouts"
      @page-change="pageChange1"
    />

    <vxe-modal
      v-model="showModal"
      resize
      destroy-on-close
      title="新增模型"
      width="800px"
      :confirm-closable="false"
    >
      <vxe-form ref="formRef" v-bind="modalFormOptions"></vxe-form>
      <div v-if="modalFormOptions.data.parmflag === '1'" class="m-[10px]">
        <vxe-table
          border
          min-height="100"
          max-height="500"
          :row-config="{ isHover: true, keyField: 'uid' }"
          :data="modalFormOptions.data.parmList"
        >
          <vxe-column type="seq" width="80"></vxe-column>
          <vxe-column field="paraString" title="参数名称">
            <template #default="{ row }">
              <vxe-input v-model="row.paraString"></vxe-input>
            </template>
          </vxe-column>
          <vxe-column field="paraValue" title="参数默认值">
            <template #default="{ row }">
              <vxe-input v-model="row.paraValue"></vxe-input>
            </template>
          </vxe-column>
          <vxe-column field="paraDesc" title="参数描述">
            <template #default="{ row }">
              <vxe-input v-model="row.paraDesc"></vxe-input>
            </template>
          </vxe-column>
        </vxe-table>
      </div>
    </vxe-modal>

    <vxe-drawer v-model="showDrawer" title="模型信息" width="50%" :loading="drawerLoading">
      <vxe-form v-bind="drawerFormOptions" class="mb-[10px]">
        <vxe-form-item title="模型ID" field="ruleId" :item-render="{}">
          <vxe-input v-model="drawerFormData.ruleId" disabled></vxe-input>
        </vxe-form-item>
        <vxe-form-item title="模型名称" field="ruleName" :item-render="{}">
          <vxe-input v-model="drawerFormData.ruleName" disabled></vxe-input>
        </vxe-form-item>
        <vxe-form-item
          v-if="drawerFormData.parmList && drawerFormData.parmList.length"
          title="模型参数"
          field="ruleParm"
          className="self-center"
        >
          <vxe-table border :row-config="{ keyField: 'id' }" :data="drawerFormData.parmList">
            <vxe-column
              v-for="item in columnsForInfo"
              :key="item.key"
              :field="item.key"
              :title="item.title"
              :show-overflow="item.overflow"
              :width="item.width ? item.width : ''"
            >
              <template v-if="item.slot === 'paraValue'" #default="{ row }">
                <vxe-input v-model="row.paraValue"></vxe-input>
              </template>
              <template v-if="item.slot === 'action'" #default="{ row }">
                <el-button type="primary" link @click="updateRow(row)">保存</el-button>
              </template>
            </vxe-column>
          </vxe-table>
        </vxe-form-item>
        <vxe-form-item title="模型描述" field="modelDesc" className="self-center">
          <vxe-textarea
            v-model="drawerFormData.modelDesc"
            :autosize="{ minRows: 2, maxRows: 2 }"
          ></vxe-textarea>
        </vxe-form-item>
        <vxe-form-item title="模型代码" field="ruleProg" className="self-center">
          <vxe-textarea
            v-model="drawerFormData.ruleProg"
            :autosize="{ minRows: 6, maxRows: 6 }"
            disabled
          ></vxe-textarea>
        </vxe-form-item>
        <vxe-form-item className="mx-[100px]">
          <template #default>
            <vxe-button
              type="reset"
              status="primary"
              content="更新"
              @click="updateInfo"
            ></vxe-button>
          </template>
        </vxe-form-item>
      </vxe-form>
    </vxe-drawer>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { SizeEnum } from "@/enums/SizeEnum";
import { AlignEnum } from "@/enums/LayoutEnum";
import ImportWorkAPI from "@/api/work";
import { convertDataJsonForTable, filterObject, guid } from "@/utils/index";
import type { VxeFormProps, VxeFormListeners, VxeFormInstance } from "vxe-pc-ui";
import { cloneDeep } from "lodash-es";
import { tableLayouts, columnsForInfo } from "@/utils/constant";
import PageModuleAPI from "@/api/module";

interface RowVO {
  id: number;
  name: string;
  role: string;
  sex: string;
  age: number;
  address: string;
}

const tableData = ref<RowVO[]>([]);
const columns = [
  {
    title: "模型名称",
    key: "ruleName",
    align: "center",
  },
  {
    title: "模型类型",
    key: "ruleType",
    align: "center",
    width: 120,
  },
  {
    title: "模型来源",
    key: "modelSource",
    align: "center",
    width: 200,
  },
  {
    title: "执行语言",
    key: "taskProgram",
    width: 120,
    align: "center",
  },
  {
    title: "删除标志",
    key: "CDelFlag",
    align: "center",
    width: 120,
  },
  {
    title: "写入时间",
    key: "DInsert",
    align: "center",
    width: 200,
  },
  {
    title: "操作",
    align: "center",
    slot: "action",
    width: 120,
  },
];
interface FormDataVO {
  ruleName: string;
}

const formOptions = reactive<VxeFormProps<FormDataVO>>({
  data: {
    ruleName: "",
  },
  items: [
    {
      field: "ruleName",
      title: "",
      span: 6,
      itemRender: {
        name: "VxeInput",
        props: { clearable: true, placeholder: "模型名称", prefixIcon: "vxe-icon-search" },
      },
    },
    {
      span: 3,
      itemRender: {
        name: "VxeButtonGroup",
        events: {
          click(slotParams, { name }) {
            if (name === "add") {
              addEvent();
            }
          },
        },
        options: [
          { type: "submit", content: "查询", status: "primary" },
          { name: "add", content: "新增", status: "primary" },
        ],
      },
    },
  ],
});

const submit = () => {
  queryParams.value.currentPage = 1;
  pageChange1(queryParams.value);
};

const addEvent = () => {
  modalFormOptions.data = cloneDeep(defaultFormData);
  showModal.value = true;
};

const defaultParams = {
  currentPage: 1,
  totalCount: 1,
  totalPage: 1,
  isNext: true,
  isLast: false,
  indexCount: 0,
  everyCount: 10,
  whereStr: "{}",
  serviceName: "ruleDefServiceImpl",
  conditionList: [],
  paramJson: "{}",
};
const type = "2";
const queryParams = ref<any>(cloneDeep(defaultParams));

// 新增模型弹窗相关
const showModal = ref(false);
interface ModalParams {
  ruleName: string;
  modelDesc: string;
  taskProgram: string;
  ruleProg: string;
  parmflag: string;
  parmList: ModalRowVO[];
  ruleType: string;
  modelSource: string;
  chartType: string;
  chartX: string;
  chartVal: string;
  ifAutoCheck: string;
}
const defaultFormData: ModalParams = {
  ruleName: "",
  modelDesc: "",
  taskProgram: "0",
  ruleProg: "",
  parmflag: "0",
  parmList: [],
  // 以下是固定传值
  ruleType: "1",
  modelSource: "1",
  chartType: "3",
  chartX: "f2",
  chartVal: "f3",
  ifAutoCheck: "0",
};
const modalFormOptions = reactive<VxeFormProps<ModalParams>>({
  titleWidth: 100,
  titleAlign: "right",
  titleColon: true,
  validConfig: { theme: "normal" },
  span: 24,
  data: cloneDeep(defaultFormData),
  rules: {
    ruleName: [{ required: true, message: "请输入模型名称" }],
    modelDesc: [{ required: true, message: "请选择模型描述" }],
    taskProgram: [{ required: true, message: "请选择程序类型" }],
    ruleProg: [{ required: true, message: "请输入模型代码" }],
    parmflag: [{ required: true }],
  },
  items: [
    {
      field: "ruleName",
      title: "模型名称",
      itemRender: { name: "VxeInput", props: { clearable: true, placeholder: "模型名称" } },
    },
    {
      field: "modelDesc",
      title: "模型描述",
      itemRender: { name: "VxeInput", props: { clearable: true, placeholder: "模型描述" } },
    },
    {
      field: "taskProgram",
      title: "程序类型",
      itemRender: {
        name: "VxeSelect",
        props: { clearable: true },
        options: [
          { label: "SQL", value: "0" },
          { label: "Procedure", value: "1" },
          { label: "Python", value: "2" },
          { label: "Java", value: "3" },
          { label: "Scala", value: "4" },
        ],
      },
    },
    {
      field: "ruleProg",
      title: "模型代码",
      className: "self-center",
      itemRender: {
        name: "VxeTextarea",
        props: {
          autosize: { minRows: 8, maxRows: 8 },
          clearable: true,
          placeholder: "模型描述",
        },
      },
    },
    {
      field: "parmflag",
      title: "参数",
      itemRender: {
        name: "VxeSelect",
        options: [
          { label: "否", value: "0" },
          { label: "是", value: "1" },
        ],
      },
    },
    {
      span: 5,
      itemRender: {
        name: "VxeButtonGroup",
        events: {
          click(slotParams, { name }) {
            if (name === "save") {
              confirmEvent(slotParams.data);
            }
            if (name === "hide") {
              hideSubEvent();
            }
          },
        },
        options: [
          { name: "save", content: "保存", status: "primary" },
          { name: "hide", content: "关闭窗口", status: "primary" },
        ],
      },
    },
    {
      span: 3,
      visibleMethod: ({ data }) => {
        console.log(data, "visibleMethod");
        return data.parmflag === "1";
      },
      itemRender: {
        name: "VxeButtonGroup",
        events: {
          click(slotParams, { name }) {
            if (name === "addParam") {
              console.log(name, slotParams, "slotParams");
              addParamEvent();
            }
          },
        },
        options: [{ name: "addParam", content: "添加参数", status: "primary" }],
      },
    },
  ],
});

// 新增模型参数
interface ModalRowVO {
  uid: string;
  paraString: string;
  paraValue: string;
  paraDesc: string;
}
const defaultModalRow = {
  uid: "",
  paraString: "",
  paraValue: "",
  paraDesc: "",
};
const formRef = ref<VxeFormInstance<FormDataVO>>();
const hideSubEvent = () => {
  const $form = formRef.value;
  $form && $form.reset();
  showModal.value = false;
};
const addParamEvent = () => {
  modalFormOptions.data.parmList.push({ ...defaultModalRow, uid: guid() });
};
const confirmEvent = async (data) => {
  const $form = formRef.value;
  if ($form) {
    const errMaps = await $form.validate();
    if (!errMaps) {
      PageModuleAPI.addModel(data).then((res) => {
        if (res.state) {
          ElMessage.success("新增模型成功");
          hideSubEvent();
        }
      });
    }
  }
};

function pageChange1(page) {
  const { currentPage, pageSize } = page;
  queryParams.value.indexCount = pageSize * currentPage - pageSize;
  initData();
}

const initData = () => {
  queryParams.value.whereStr = JSON.stringify(filterObject({ ...formOptions.data, accType: type }));
  ImportWorkAPI.getPage(queryParams.value).then((resData) => {
    if (resData?.resObj) {
      const { totalCount, totalPage, everyCount, dataJson } = resData.resObj;
      tableData.value = convertDataJsonForTable(dataJson);
      queryParams.value.totalCount = totalCount;
      queryParams.value.totalPage = totalPage;
      queryParams.value.everyCount = everyCount;
    }
  });
};

// 抽屉相关
const showDrawer = ref(false);
const drawerLoading = ref(false);
const drawerFormData = ref({});
const drawerFormOptions = reactive<VxeFormProps<ModalParams>>({
  titleWidth: 100,
  titleAlign: "right",
  titleColon: true,
  validConfig: { theme: "normal" },
  span: 24,
});
const showDrawerInfo = (info) => {
  drawerFormData.value = info;
  PageModuleAPI.getParmlist({ id: info.ruleId }).then((res) => {
    if (res.state) {
      drawerFormData.value.parmList = res?.resList || [];
      showDrawer.value = true;
    } else {
      ElMessage.error(res?.resMsg || "未知错误");
    }
  });
};
const updateRow = (row) => {
  PageModuleAPI.updateParmRow(row).then((res) => {
    if (res.state) {
      ElMessage.success("保存成功");
    } else {
      ElMessage.error(res?.resMsg || "保存失败");
    }
  });
};
const updateInfo = () => {
  PageModuleAPI.updateRuleDef(drawerFormData.value).then((res) => {
    if (res.state) {
      ElMessage.success("模型信息更新成功");
      showDrawer.value = false;
      submit();
    } else {
      ElMessage.error(res?.resMsg || "模型信息更新失败");
    }
  });
};
onMounted(() => {
  initData();
});
</script>
