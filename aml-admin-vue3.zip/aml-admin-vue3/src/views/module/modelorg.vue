<template>
  <div class="crud-container">
    <!-- 左侧树形目录 -->
    <vxe-card class="left-card">
      <div class="flex-x-end mb-[10px]">
        <el-button type="primary" @click="addRow">新增</el-button>
        <el-button type="primary" @click="delRows">删除</el-button>
      </div>

      <el-tree
        ref="treeRef"
        show-checkbox
        :node-key="'menuId'"
        :data="treeData"
        :expand-on-click-node="false"
        :props="props"
        :height="208"
        @node-click="handleNodeClick"
      >
        <template #default="{ node, data }">
          <span>{{ node.label }}</span>
        </template>
      </el-tree>
    </vxe-card>
    <div class="right-card">
      <vxe-card>
        <template #title>
          <div>
            <span>规则区</span>
          </div>
        </template>
        <vxe-form v-if="!flag" v-bind="formOptions" class="mb-[10px]">
          <vxe-form-item title="模型ID" field="ruleId" :item-render="{}">
            <vxe-input v-model="formData.ruleId" disabled></vxe-input>
          </vxe-form-item>
          <vxe-form-item title="模型名称" field="ruleName" :item-render="{}">
            <vxe-input v-model="formData.ruleName" disabled></vxe-input>
          </vxe-form-item>
          <vxe-form-item
            v-if="formData.parmList && formData.parmList.length"
            title="模型参数"
            field="ruleParm"
            className="self-center"
          >
            <vxe-table border :row-config="{ keyField: 'id' }" :data="formData.parmList">
              <vxe-column
                v-for="item in columnsForInfo"
                :key="item.key"
                :field="item.key"
                :title="item.title"
                :show-overflow="item.overflow"
                width="25%"
              >
                <template v-if="item.slot === 'paraValue'" #default="{ row }">
                  <vxe-input v-model="row.paraValue"></vxe-input>
                </template>
                <template v-if="item.slot === 'action'" #default="{ row }">
                  <el-button type="primary" link @click="updateRow(row)">保存</el-button>
                </template>
              </vxe-column>
            </vxe-table>
          </vxe-form-item>
          <vxe-form-item title="模型描述" field="modelDesc" className="self-center">
            <vxe-textarea
              v-model="formData.modelDesc"
              :autosize="{ minRows: 2, maxRows: 2 }"
              disabled
            ></vxe-textarea>
          </vxe-form-item>
          <vxe-form-item title="模型代码" field="ruleProg" className="self-center">
            <vxe-textarea
              v-model="formData.ruleProg"
              :autosize="{ minRows: 6, maxRows: 6 }"
              disabled
            ></vxe-textarea>
          </vxe-form-item>
        </vxe-form>
        <vxe-textarea
          v-else
          v-model="nodeDesc"
          :autosize="{ minRows: 10, maxRows: 10 }"
          resize="vertical"
        ></vxe-textarea>
      </vxe-card>

      <!-- 新增数据 -->
      <vxe-drawer v-model="showDrawer" title="新增" width="50%">
        <vxe-form v-bind="formOptions" :data="drawerFormData" class="mb-[10px]">
          <vxe-form-item title="类型" field="type" :item-render="typeItemRender" />
          <vxe-form-item title="目录名称" field="title" :item-render="{ name: 'VxeInput' }" />
          <vxe-form-item title="父级名称" field="parentId">
            <vxe-select v-model="drawerFormData.parentId" :options="menuList">
              <template #option="{ option }">
                <span>{{ option.label }}</span>
              </template>
            </vxe-select>
          </vxe-form-item>
          <vxe-form-item title="描述信息" field="titleDesc" :item-render="modelDescItemRender" />
          <vxe-form-item className="mx-[100px]">
            <template #default>
              <vxe-button status="primary" content="提交" @click="addNode"></vxe-button>
            </template>
          </vxe-form-item>
        </vxe-form>
      </vxe-drawer>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { ref } from "vue";
import type { VxeFormProps, VxeFormItemPropTypes } from "vxe-pc-ui";
import { columnsForInfo } from "@/utils/constant";
import ImportWorkAPI from "@/api/work";
import PageModuleAPI from "@/api/module";
import { ElLoading } from "element-plus";

const props = {
  value: "menuId",
  label: "title",
  children: "children",
};
const treeData = ref([]);
const treeRef = ref();
const nodeDesc = ref("");
// 右侧规则区相关
const flag = computed(() => {
  // menuType 0是目录，menuType 1是模型
  return formData.value?.menuType === "1" ? false : true;
});
const menuList = ref([]);
const formData = ref({});
const formOptions = reactive<VxeFormProps>({
  titleWidth: 100,
  titleAlign: "right",
  titleColon: true,
  validConfig: { theme: "normal" },
  span: 24,
});
// 递归获取所有目录数据
const flattenMenuTree = (data) => {
  const result = [];

  const traverse = (nodes) => {
    nodes.forEach((node) => {
      if (node.menuType === "0") {
        result.push({
          label: node.title,
          value: node.menuId.toString(),
        });
        if (node.children) {
          traverse(node.children);
        }
      }
    });
  };

  traverse(data);
  return result;
};
const init = () => {
  ImportWorkAPI.getRuleTree().then((res) => {
    treeData.value = res?.resList || [];
    const list = [
      {
        menuId: "0",
        patentId: "-1",
        menuType: "0",
        title: "顶级菜单",
      },
    ].concat(treeData.value);
    menuList.value = flattenMenuTree(list);
  });
};
const handleNodeClick = (row) => {
  nodeDesc.value = "";
  if (row.menuType === "1") {
    PageModuleAPI.getModelInfo({ id: row.ruleId }).then((res) => {
      if (res.state) {
        formData.value = { ...res.resObj, menuType: "1" };
      }
    });
  } else {
    formData.value = row;
    nodeDesc.value = row.nodeDesc;
  }
};
const delRows = () => {
  const $treeRef = treeRef.value;
  const menuIds = $treeRef.getCheckedNodes(false).map((e) => e.menuId);
  console.log(menuIds, "mm");
  if (!menuIds.length) {
    ElMessage.error("请至少选择一项");
    return false;
  }

  ElMessageBox.confirm("确定要继续删除吗？", "删除确认", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  }).then(() => {
    PageModuleAPI.delNode({ nodeIds: String(menuIds) }).then((res) => {
      if (res.state) {
        ElMessage.success("删除成功");
        init();
      }
    });
  });
};
const updateRow = (row) => {
  PageModuleAPI.updateParmRow(row).then((res) => {
    if (res.state) {
      ElMessage.success("保存成功");
    } else {
      ElMessage.error(res?.resMsg || "保存失败");
    }
  });
};

// 新增目录、模型表单相关
const showDrawer = ref(false);
const drawerFormData = ref({
  type: "0",
});
const typeItemRender = reactive<VxeFormItemPropTypes.ItemRender>({
  name: "VxeSelect",
  options: [
    { label: "目录", value: "0" },
    { label: "模型", value: "1" },
  ],
});
const modelDescItemRender = reactive<VxeFormItemPropTypes.ItemRender>({
  name: "VxeTextarea",
  props: {
    autosize: { minRows: 8, maxRows: 8 },
    clearable: true,
    placeholder: "模型描述",
  },
});
const addNode = () => {
  PageModuleAPI.addNode(drawerFormData.value).then((res) => {
    if (res.state) {
      showDrawer.value = false;
      init();
    }
  });
};
const addRow = () => {
  drawerFormData.value = {
    type: "0",
  };
  showDrawer.value = true;
};

onMounted(() => {
  init();
});
</script>

<style lang="scss" scoped>
.crud-container {
  @apply flex space-x-2;
}
.left-card {
  @apply h-full min-w-[310px] max-w-[310px] flex-x-center text-center bg-[#dddddd];
  border-radius: 0;
  .el-tree {
    background: #dddddd;
  }
}
.right-card {
  @apply h-full min-w-[calc(100%-320px)] max-w-[calc(100%-320px)] bg-[#dddddd] p-4;
  .vxe-card {
    @apply w-full h-full;
  }
}
</style>
