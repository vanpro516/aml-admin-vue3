<template>
  <div class="crud-container">
    <!-- 左侧树形目录 -->
    <vxe-card shadow class="left-card">
      <template #title>
        <div class="flex justify-between">
          <span class="text-[16px]">自定义sql步骤</span>
        </div>
      </template>
      <el-steps :active="activeStep" direction="vertical" class="!h-[300px] w-full">
        <el-step title="步骤一" description="选择表和字段"></el-step>
        <el-step title="步骤二" description="设置查询条件"></el-step>
        <el-step title="步骤三" description="查看查询结果"></el-step>
      </el-steps>
      <div class="flex-x-center mt-[20px]">
        <el-button type="primary" @click="prevStep">上一步</el-button>
        <el-button type="primary" @click="nextStep">下一步</el-button>
      </div>
    </vxe-card>
    <vxe-card shadow class="right-card">
      <template #title>
        <span class="text-[16px]">操作区</span>
      </template>
      <template v-if="activeStep === 0">
        <div class="flex justify-between p-6 border border-[#dcdfe6] h-full">
          <div class="w-[300px] h-full">
            <div class="flex-x-between">
              <span>选择表:</span>
              <vxe-select
                v-model="formEntity.tableName"
                :options="tableNameList"
                placeholder="请选择表"
                class="!w-[80%]"
                @change="changeTableName"
              ></vxe-select>
            </div>

            <div v-if="tableColList && tableColList.length" class="my-4">
              <vxe-checkbox
                v-model="choseAll"
                class="float-end"
                content="全选"
                :indeterminate="isIndeterminate"
                @change="handleAllChange"
              ></vxe-checkbox>
              <vxe-checkbox-group
                v-model="choseTableCols"
                :options="tableColList"
                class="first-node"
                @change="handleItemChange"
              ></vxe-checkbox-group>
            </div>
          </div>
          <div class="w-[calc(100%-320px)]">
            <vxe-table border min-height="100px" height="100%" :data="tableData">
              <vxe-column field="tableName" title="已选择表"></vxe-column>
              <vxe-column field="title" title="已选择字段"></vxe-column>
            </vxe-table>
          </div>
        </div>
      </template>

      <template v-if="activeStep === 1">
        <div class="h-[95%]">
          <div class="flex pl-[0.6em]">
            <span>条件关联关系：</span>
            <vxe-radio-group v-model="relation" :options="relationOptions"></vxe-radio-group>
          </div>
          <vxe-grid v-bind="gridOptions">
            <template #action="{ row }">
              <el-button type="primary" link @click="delRow(row)">移除</el-button>
            </template>
          </vxe-grid>
        </div>
      </template>

      <template v-if="activeStep === 2">
        <div class="h-[95%] m-[0.3em]">
          <div class="flex justify-between mb-[10px]">
            <div>
              <span class="text">
                共
                <span class="red-text">{{ total }}</span>
                条记录
              </span>
            </div>
            <el-button type="primary" @click="openDrawer">保存为模型</el-button>
          </div>
          <vxe-table :data="recordData" border min-height="100px" height="100%">
            <vxe-column
              v-for="item in tableData"
              :key="item.key"
              :field="item.key"
              :title="item.title"
              show-overflow="true"
              width="auto"
            ></vxe-column>
          </vxe-table>
        </div>
      </template>
    </vxe-card>

    <!-- 保存为模型 -->
    <vxe-drawer v-model="showDrawer" title="保存为模型" width="50%">
      <vxe-form v-bind="formOptions" :data="drawerFormData" class="mb-[10px]">
        <vxe-form-item title="模型名称" field="ruleName" :item-render="{ name: 'VxeInput' }" />
        <vxe-form-item title="父级名称" field="menuId">
          <vxe-select v-model="drawerFormData.menuId" :options="menuList">
            <template #option="{ option }">
              <span>{{ option.title }}</span>
            </template>
          </vxe-select>
        </vxe-form-item>
        <vxe-form-item title="描述信息" field="modelDesc" :item-render="modelDescItemRender" />
        <vxe-form-item className="mx-[100px]">
          <template #default>
            <vxe-button status="primary" content="提交" @click="addNode"></vxe-button>
          </template>
        </vxe-form-item>
      </vxe-form>
    </vxe-drawer>
  </div>
</template>

<script lang="ts" setup>
import { ref, computed, reactive } from "vue";
import { conditionList } from "@/utils/constant";
import ImportWorkAPI from "@/api/work";
// import PageBaseAPI from "@/api/base";
import PageModuleAPI from "@/api/module";
import type { VxeFormProps, VxeFormItemPropTypes } from "vxe-pc-ui";
import { VxeGridProps } from "vxe-pc-ui/types/components/grid";
// import { guid } from "@/utils";

// 常量定义
const STEP_ONE = 0;
const STEP_TWO = 1;
const STEP_THREE = 2;

const activeStep = ref(STEP_ONE); // 当前步骤索引
const tableNameList = ref([]);
const formEntity = ref({});
// const fileUrl = ref("public/徐浩-422130199110094111.doc");
const COLUMNS = [
  {
    title: "模型ID",
    key: "ruleId",
    align: "center",
  },
  {
    title: "模型名称",
    key: "ruleName",
    overflow: true,
    width: 300,
    align: "center",
  },
  {
    title: "模型描述",
    key: "modelDesc",
    align: "center",
    overflow: true,
    width: 400,
  },
];

// 初始化数据
const init = () => {
  ImportWorkAPI.getTargetTab().then((res: any) => {
    tableNameList.value = (res?.resList || []).map((option: any) => ({
      value: option?.tableName,
      label: `${option?.tableName}@${option?.tableDesc}`,
    }));
  });
  ImportWorkAPI.getRuleTree().then((res: any) => {
    let list = res?.resList || [];
    menuList.value = [
      {
        menuId: "0",
        title: "顶级菜单",
      },
    ].concat(list);
  });
  console.log(menuList, "【 menuList 】");
};

// 上一步
const prevStep = () => {
  if (activeStep.value > STEP_ONE) {
    activeStep.value--;
  }
};

const nextStep = () => {
  if (!choseTableCols.value.length) {
    return ElMessage.error("请先选择表和字段");
  }
  if (activeStep.value == STEP_TWO && !gridOptions.data.length) {
    return ElMessage.error("请先选择表和字段");
  }
  if (activeStep.value < STEP_THREE) {
    activeStep.value++;
  }
};

// 步骤一相关
const choseAll = ref(false);
const choseTableCols = ref([]);
const tableColList = ref([]);
const isIndeterminate = computed(() => {
  return choseTableCols.value.length > 0 && choseTableCols.value.length < tableColList.value.length;
});

const tableData = computed(() => {
  return tableColList.value.filter((item: any) => choseTableCols.value.includes(item.value));
});

const handleAllChange = () => {
  choseAll.value ? selectAllColumns() : clearSelectedColumns();
};

const handleItemChange = () => {
  const allChecked = tableColList.value.every((item) => choseTableCols.value.includes(item.value));
  choseAll.value = allChecked;
};

// 步骤一：表change
const changeTableName = () => {
  fetchTableColumns();
};

const fetchTableColumns = () => {
  PageModuleAPI.getTableColList({ tableName: formEntity?.value?.tableName }).then((res: any) => {
    if (res?.state) {
      tableColList.value = (res?.resList || []).map((ele: any) => ({
        tableName: ele.tableName,
        dataType: ele.dataType,
        title: ele.columnDesc,
        label: ele.columnDesc,
        value: ele.columnName,
        key: ele.columnName,
        align: "center",
      }));
    }
  });
};

// 步骤二相关
interface RowVO {
  column: string;
  conditionType: string;
  value: string;
}

const relation = ref("AND");
const gridOptions = reactive<VxeGridProps<RowVO>>({
  showOverflow: true,
  border: true,
  height: "100%",
  formConfig: {
    titleColon: true,
    data: {
      column: "",
      conditionType: "",
      value: "",
    },
    items: [
      {
        field: "column",
        title: "字段",
        itemRender: {
          name: "VxeSelect",
          props: { clearable: true },
          options: tableColList,
        },
      },
      {
        field: "conditionType",
        title: "条件",
        itemRender: {
          name: "VxeSelect",
          props: { clearable: true },
          options: conditionList,
        },
      },
      { field: "value", title: "参数/值", itemRender: { name: "VxeInput" } },
      {
        itemRender: {
          name: "VxeButtonGroup",
          options: [
            { name: "addBtn", content: "新增", status: "primary" },
            { name: "search", content: "查询", status: "primary" },
          ],
          events: {
            click(slotParams, { name }) {
              if (name === "addBtn") {
                addConditionFn();
              }
              if (name === "search") {
                searchEvent();
              }
            },
          },
        },
      },
    ],
  },
  columns: [
    { field: "column", title: "字段", align: "center" },
    { field: "columnDesc", title: "字段说明", align: "center" },
    { field: "conditionType", title: "条件", align: "center" },
    { field: "value", title: "参数/值", align: "center" },
    {
      title: "操作",
      slots: { default: "action" },
      field: "action",
      width: 80,
      align: "center",
    },
  ],
  data: [],
});

const relationOptions = [
  { label: "AND", value: "AND" },
  { label: "OR", value: "OR" },
];

// 第二步新增
const addConditionFn = () => {
  const data: any = gridOptions.formConfig?.data;
  const { column, conditionType, value } = data;
  if (!column) {
    return ElMessage.error("请选择字段");
  }
  if (!conditionType) {
    return ElMessage.error("请选择条件");
  }
  if (!value) {
    return ElMessage.error("请填选参数值");
  }
  const columnDesc = getColumnDesc(data.column);
  const dataType = getDataType(data.column);
  gridOptions.data.push({ ...data, columnDesc, dataType });
  resetFormConfig();
};

// 第二步查询
const searchEvent = () => {
  recordData.value = []; // 清空列表
  const params = {
    columnList: choseTableCols.value,
    conditionList: gridOptions.data,
    relation: relation.value,
    tableName: formEntity.value?.tableName,
  };
  PageModuleAPI.getListBySql(params).then((res: any) => {
    if (res?.state) {
      const { data, count } = res.resMap;
      total.value = count;
      recordData.value = data;
    }
    activeStep.value++; // 跳转第三步
  });
};

// 步骤三
const total = ref(0);
const recordData = ref([]);
const showDrawer = ref(false); // 控制抽屉显示
const drawerFormData = ref({});
const menuList = ref([]);
const formOptions = reactive<VxeFormProps>({
  titleWidth: 100,
  titleAlign: "right",
  titleColon: true,
  validConfig: { theme: "normal" },
  span: 24,
});
const modelDescItemRender = reactive<VxeFormItemPropTypes.ItemRender>({
  name: "VxeTextarea",
  props: {
    autosize: { minRows: 8, maxRows: 8 },
    clearable: true,
    placeholder: "模型描述",
  },
});
// 保存为模型
const openDrawer = () => {
  showDrawer.value = true;
};
// 保存为模型
const addNode = () => {
  const data: any = drawerFormData.value;
  const { ruleName, menuId, modelDesc } = data;
  console.log(data, "【 addNode 】");
  if (!ruleName) {
    return ElMessage.error("请填写模型名称");
  }
  if (!menuId) {
    return ElMessage.error("请选择父级名称");
  }
  if (!modelDesc) {
    return ElMessage.error("请填写描述名称");
  }
  PageModuleAPI.addNode(data).then((res: any) => {
    if (res.state) {
      showDrawer.value = false;
      init();
    }
  });
};
const delRow = (row: any) => {
  const currentIndex = gridOptions.data?.findIndex((ele: any) => ele.uid === row.uid);
  if (currentIndex !== -1) {
    gridOptions.data?.splice(currentIndex, 1);
  }
};
const resetFormConfig = () => {
  gridOptions.formConfig.data = {
    column: "",
    conditionType: "",
    value: "",
  };
};

const selectAllColumns = () => {
  choseTableCols.value = tableColList.value.map((item: any) => item.value);
};

const clearSelectedColumns = () => {
  choseTableCols.value = [];
};

const getColumnDesc = (column: any) => {
  return tableColList.value.find((ele: any) => ele.value === column)?.title;
};

const getDataType = (column: any) => {
  return tableColList.value.find((ele: any) => ele.value === column)?.dataType;
};

onMounted(() => {
  init();
});
</script>

<style lang="scss" scoped>
.crud-container {
  @apply flex space-x-4 p-4;
}
.left-card {
  @apply h-full min-w-[310px] max-w-[310px] flex-x-center text-center;
}
.right-card {
  @apply h-full w-[calc(100%-320px)];
}
.text {
  font-size: 16px;
  font-weight: 600;
}
.red-text {
  font-size: 20px;
  color: red;
}
</style>
