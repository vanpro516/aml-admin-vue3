<template>
  <vxe-modal v-model="show" resize :title="`文件预览`" width="90%" height="90%">
    <iframe
      v-if="fileType === 'pdf'"
      :src="url + '#toolbar=0'"
      frameborder="0"
      class="iframe-box"
    ></iframe>

    <vue-office-docx v-else-if="fileType === 'docx' || fileType === 'doc'" :src="url" />

    <vue-office-excel
      v-else-if="fileType === 'xlsx' || fileType === 'xls'"
      :src="url"
      class="set-excel"
    />

    <img v-else :src="url" class="img-box" />
  </vxe-modal>
</template>

<script setup>
import { defineProps, ref, defineEmits, watch } from "vue";
//引入VueOfficeDocx组件
import VueOfficeDocx from "@vue-office/docx";
//引入相关样式
import "@vue-office/docx/lib/index.css";
// excel组件
import VueOfficeExcel from "@vue-office/excel";
import "@vue-office/excel/lib/index.css";

const props = defineProps({
  visible: {
    type: Boolean,
    default: false,
  },
  url: {
    type: String,
    default: "",
  },
});
const fileType = ref("");

const emit = defineEmits(["update:visible"]);
const show = computed({
  get: () => props.visible,
  set: (value) => emit("update:visible", value),
});
const getFileExtension = (url) => {
  // 处理包含查询参数或哈希的情况
  const cleanUrl = url.split(/[?#]/)[0];
  // 获取最后一个斜杠后的文件名
  const filename = cleanUrl.substring(cleanUrl.lastIndexOf("/") + 1);
  // 分割文件名获取后缀（考虑带多个点的文件名）
  return filename.includes(".") ? filename.split(".").pop().toLowerCase() : "";
};

watch(
  () => props.visible,
  (val) => {
    if (val) {
      fileType.value = getFileExtension(props.url);
    }
  },
  { immediate: true, deep: true }
);
</script>

<style scoped>
.iframe-box,
.img-box {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.set-excel {
  height: 100%;
}
</style>
