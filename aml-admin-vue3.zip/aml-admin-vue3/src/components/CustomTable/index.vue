<template>
  <div class="table-operation">
    <!-- 按钮区域 -->
    <div class="table-operation-buttons">
      <template v-for="(button, index) in buttons" :key="index">
        <el-button :type="button.type" @click="button.onClick">
          {{ button.label }}
        </el-button>
      </template>
    </div>

    <!-- 表格 -->
    <el-table :data="tableData" border style="width: 100%" :style="tableStyle">
      <template v-for="(column, index) in tableConfig" :key="index">
        <el-table-column
          v-if="column.type !== 'operation'"
          :prop="column.prop"
          :label="column.label"
          :width="column.width"
        >
          <template #default="scope">
            <component v-if="column.cellRenderer" :is="column.cellRenderer" :row="scope.row" />
            <span v-else>{{ scope.row[column.prop] }}</span>
          </template>
        </el-table-column>
      </template>
    </el-table>
  </div>
</template>

<script setup>
import { ref, computed } from "vue";

const props = defineProps({
  tableData: {
    type: Array,
    required: true,
  },
  tableConfig: {
    type: Array,
    required: true,
  },
  buttons: {
    type: Array,
    default: () => [],
  },
});

const tableStyle = computed(() => {
  const totalWidth = props.tableConfig.reduce((sum, column) => sum + (column.width || 0), 0);
  return {
    overflowX: totalWidth > 1000 ? "auto" : "hidden",
  };
});
</script>

<style scoped>
.table-operation-buttons {
  margin-bottom: 20px;
  display: flex;
  gap: 10px;
}

.table-operation {
  position: relative;
}

.el-table {
  overflow: hidden;
}
</style>