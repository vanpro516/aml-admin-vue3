<template>
  <div class="search-form">
    <el-form :model="searchForm" inline>
      <template v-for="(item, index) in searchConfig" :key="index">
        <el-form-item :label="item.label" :prop="item.prop">
          <component
            :is="getComponent(item.type)"
            v-model="searchForm[item.prop]"
            v-bind="item.props"
            :style="item.width ? item.width : '200px'"
          />
        </el-form-item>
      </template>
      <el-form-item>
        <el-button type="primary" @click="onQuery">查询</el-button>
        <el-button @click="onReset">重置</el-button>
        <el-button type="success" @click="onRefresh">刷新</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script setup>
import { ref, computed } from "vue";

const props = defineProps({
  searchConfig: {
    type: Array,
    required: true,
  },
  searchForm: {
    type: Object,
    required: true,
  },
});

const emit = defineEmits(["query", "reset", "refresh"]);

const getComponent = (type) => {
  const componentMap = {
    input: "el-input",
    select: "el-select",
    date: "el-date-picker",
  };
  return componentMap[type] || "el-input";
};

const onQuery = () => {
  emit("query", props.searchForm);
};

const onReset = () => {
  emit("reset");
};

const onRefresh = () => {
  emit("refresh");
};
</script>

<style scoped>
.search-form {
  margin-bottom: 20px;
}
</style>