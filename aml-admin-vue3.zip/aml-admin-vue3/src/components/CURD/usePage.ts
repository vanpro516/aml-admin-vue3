import { ref } from "vue";
import type { IObject, PageContentInstance, PageModalInstance, PageSearchInstance } from "./types";

function usePage() {
  const searchRef = ref<PageSearchInstance>();
  const contentRef = ref<PageContentInstance>();
  const addModalRef = ref<PageModalInstance>();
  const editModalRef = ref<PageModalInstance>();
  const defaultParams = {
    currentPage: 1,
    totalCount: 0,
    totalPage: 0,
    isNext: false,
    isLast: false,
    indexCount: 0,
    everyCount: 10,
    // whereStr: queryParams ? JSON.stringify(queryParams) : "{}",
    whereStr: "{}",
    indexList: [],
    serviceName: "importFileServiceTwoImpl",
    conditionList: [],
    paramJson: "{}",
  };

  // 搜索
  function handleQueryClick(queryParams: IObject) {
    const filterParams = contentRef.value?.getFilterParams();
    console.log("queryParams>>", queryParams);
    console.log("filterParams>>", filterParams);
    contentRef.value?.fetchPageData(
      { ...defaultParams, whereStr: queryParams.tableName ? JSON.stringify(queryParams) : "{}" },
      true
    );
  }
  // 重置
  function handleResetClick(queryParams: IObject) {
    contentRef.value?.fetchPageData(
      { ...defaultParams, whereStr: queryParams.tableName ? JSON.stringify(queryParams) : "{}" },
      true
    );
  }
  // 新增
  function handleAddClick() {
    //显示添加表单
    addModalRef.value?.setModalVisible();
  }
  // 编辑
  function handleEditClick(row: IObject) {
    //显示编辑表单 根据数据进行填充
    editModalRef.value?.setModalVisible(row);
  }
  // 表单提交
  function handleSubmitClick() {
    //根据检索条件刷新列表数据
    const queryParams = searchRef.value?.getQueryParams();
    contentRef.value?.fetchPageData(queryParams, true);
  }
  // 导出
  function handleExportClick() {
    // 根据检索条件导出数据
    const queryParams = searchRef.value?.getQueryParams();
    contentRef.value?.exportPageData(queryParams);
  }
  // 搜索显隐
  function handleSearchClick() {
    searchRef.value?.toggleVisible();
  }
  // 涮选数据
  function handleFilterChange(filterParams: IObject) {
    const queryParams = searchRef.value?.getQueryParams();
    contentRef.value?.fetchPageData({ ...queryParams, ...filterParams }, true);
  }

  return {
    searchRef,
    contentRef,
    addModalRef,
    editModalRef,
    handleQueryClick,
    handleResetClick,
    handleAddClick,
    handleEditClick,
    handleSubmitClick,
    handleExportClick,
    handleSearchClick,
    handleFilterChange,
  };
}

export default usePage;
