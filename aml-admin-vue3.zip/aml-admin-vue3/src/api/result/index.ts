import request from "@/utils/request";
import qs from "qs";

const PageResultAPI = {
  /**
   * 下载报告
   */
  downloadReport(params) {
    return request<any, PageResult<[]>>({
      url: `/api/report`,
      method: "get",
      responseType: "blob",
      params,
    });
  },

  /**
   * 获取全部的批次号
   */
  getAllBatchNo() {
    return request<any, PageResult<[]>>({
      url: `/api/getAllBatchNo`,
      method: "get",
    });
  },

  /**
   * 获取批次号列表
   */
  getBatchIds() {
    return request<any, PageResult<[]>>({
      url: `/modelResult/batchIds`,
      method: "get",
    });
  },

  /**
   * SQL查询分析器
   */
  sqlClientQuery(data) {
    return request<any, PageResult<[]>>({
      url: `/sqlclient/query`,
      method: "post",
      showErrorMsg: false,
      data,
    });
  },
};
export default PageResultAPI;

export interface UserProfileForm {
  /** 用户ID */
  id?: number;
  /** 用户名 */
  username?: string;
  /** 昵称 */
  nickname?: string;
  /** 头像URL */
  avatar?: string;
  /** 性别 */
  gender?: number;
  /** 手机号 */
  mobile?: string;
  /** 邮箱 */
  email?: string;
}
