import request from "@/utils/request";
import qs from "qs";

const ImportModelAPI = {
  /**
   * 获取检测报告结果
   */
  getModelTreelist() {
    return request<any, PageResult<UserPageVO[]>>({
      url: `/ruledef/modelTreelist`,
      method: "get",
    });
  },

  /**
   * 重新检测
   */
  resetCheck(data) {
    return request({
      url: `/ruledef/resetCheck`,
      method: "post",
      data,
    });
  },
};

export default ImportModelAPI;
