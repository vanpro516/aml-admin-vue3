import request from "@/utils/request";
import { FileInfo } from "../file";

const PageBaseAPI = {
  /**
   * 获取模型列表（树形结构）
   *
   * @param data 查询参数
   */
  getList() {
    return request<any, PageResult<[]>>({
      url: `/ruledef/modellist`,
      method: "post",
    });
  },

  /**
   * 获取模型列表（树形结构）
   */
  getTableMetadata(params) {
    return request<any, PageResult<[]>>({
      url: `/tableMetadata/page`,
      method: "get",
      params,
    });
  },

  /**
   * 法律法规文件上传列表
   */
  getLegalPageList(params) {
    return request<any, PageResult<[]>>({
      url: `/legalDocument/page`,
      method: "get",
      params,
    });
  },

  /**
   * 上传法律法规文件
   *
   * @param formData
   */
  postLegalDocument(formData: FormData) {
    return request<any, FileInfo>({
      url: "/legalDocument/upload",
      method: "post",
      data: formData,
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
  },
};

export default PageBaseAPI;
