import request from "@/utils/request";

const SysTenantAPI = {
  /**
   * 获取租户列表
   */
  getTenantList(params) {
    return request<any, any>({
      url: `/sys/tenant/list`,
      method: "get",
      params,
    });
  },

  /**
   * 新增租户
   */
  addTenant(data) {
    return request<any, any>({
      url: `/sys/tenant/add`,
      method: "post",
      data,
    });
  },

  /**
   * 删除租户
   */
  deleteTenant(params) {
    return request<any, any>({
      url: `/sys/tenant/delete`,
      method: "delete",
      params,
    });
  },
};

export default SysTenantAPI;
