import ImportWorkAPI from "@/api/work";

/**
 * Check if an element has a class
 * @param {HTMLElement} ele
 * @param {string} cls
 * @returns {boolean}
 */
export function hasClass(ele: HTMLElement, cls: string) {
  return !!ele.className.match(new RegExp("(\\s|^)" + cls + "(\\s|$)"));
}

/**
 * Add class to element
 * @param {HTMLElement} ele
 * @param {string} cls
 */
export function addClass(ele: HTMLElement, cls: string) {
  if (!hasClass(ele, cls)) ele.className += " " + cls;
}

/**
 * Remove class from element
 * @param {HTMLElement} ele
 * @param {string} cls
 */
export function removeClass(ele: HTMLElement, cls: string) {
  if (hasClass(ele, cls)) {
    const reg = new RegExp("(\\s|^)" + cls + "(\\s|$)");
    ele.className = ele.className.replace(reg, " ");
  }
}

/**
 * 判断是否是外部链接
 *
 * @param {string} path
 * @returns {Boolean}
 */
export function isExternal(path: string) {
  const isExternal = /^(https?:|http?:|mailto:|tel:)/.test(path);
  return isExternal;
}

/**
 * 格式化增长率，保留两位小数 ，并且去掉末尾的0  取绝对值
 *
 * @param growthRate
 * @returns
 */
export function formatGrowthRate(growthRate: number) {
  if (growthRate === 0) {
    return "-";
  }

  const formattedRate = Math.abs(growthRate * 100)
    .toFixed(2)
    .replace(/\.?0+$/, "");
  return formattedRate + "%";
}

export function joinTimestamp(join: boolean, restful = false): string | object {
  if (!join) {
    return restful ? "" : {};
  }
  const now = new Date().getTime();
  if (restful) {
    return `?_t=${now}`;
  }
  return { _t: now };
}

export function convertDataJsonForTable(data) {
  return data == null ? [] : JSON.parse(data);
}

/** 浏览器保存文件 */
export function saveFile(fileData: any, fileName: string, fileType: string) {
  const blob = new Blob([fileData], { type: fileType });
  const downloadUrl = window.URL.createObjectURL(blob);

  const downloadLink = document.createElement("a");
  downloadLink.href = downloadUrl;
  downloadLink.download = fileName;

  document.body.appendChild(downloadLink);
  downloadLink.click();

  document.body.removeChild(downloadLink);
  window.URL.revokeObjectURL(downloadUrl);
}

/** 从原始路径截取文件名称 */
export function extractFileName(path) {
  // 使用 lastIndexOf 找到最后一个反斜杠的位置
  const lastSlashIndex = path.includes("\\") ? path.lastIndexOf("\\") : path.lastIndexOf("/");
  // 如果找到反斜杠，截取其后的部分；否则返回原始路径
  console.log(path, "path--");
  return lastSlashIndex !== -1 ? path.substring(lastSlashIndex + 1) : path;
}

/**
 * 从树中找出匹配节点
 *
 * @param {array} data 树
 * @param {string} key 键值
 * @param {string} value 值
 * @returns {array} 匹配结果
 */
export function findNodesByType(data, key, value) {
  let result = [];
  function traverse(node) {
    if (node[key] === value) {
      result.push(node);
    }
    if (node.children && node.children.length > 0) {
      node.children.forEach((child) => traverse(child));
    }
  }
  data.forEach((node) => traverse(node));
  return result;
}

/**
 * 获取映射值
 *
 * @param {Map} map 映射对象
 * @param {string} value 键值
 * @param {defaultValue} value 匹配不到时的显示值
 * @returns {string} 匹配结果
 */
export function getMappedValue<T extends string | number>(
  map: Record<T, string>,
  value: T,
  defaultValue?: string
): string {
  if (value in map) {
    return map[value];
  } else {
    return defaultValue !== undefined ? defaultValue : "";
  }
}

/** 从对象数组中根据 value 查找对应 label */
export function findLabelByValue(list, value) {
  const item = list.find((item) => item.value === value);
  return item ? item.label : "";
}

/** 判断是否需要构造，返回的新对象 */
export function filterObject(obj) {
  const newObj = {};
  for (const key in obj) {
    // 确保属性属于该对象本身（可选）
    if (obj.hasOwnProperty(key)) {
      const value = obj[key];

      // 如果值为 null 或空字符串，则跳过
      if (value === null || value === "") {
        continue;
      }
      if (value === 0 || Boolean(value)) {
        newObj[key] = value;
      }
    }
  }
  return newObj;
}

/**
 * 下载文件
 *
 * @param {object} row 下载对象
 */
export function downloadFileByFileId(row) {
  const path = row.oriPath ?? row.rerultPath;
  if (!path) {
    return ElMessage.error("文件路径不存在");
  }
  ImportWorkAPI.downloadFile({ path, fileId: row?.fileId || "" }).then((response) => {
    const fileData = response.data;
    let fileName;
    if (response?.headers["content-disposition"]) {
      fileName = decodeURI(response.headers["content-disposition"].split(";")[1].split("=")[1]);
    } else {
      fileName = extractFileName(path);
      console.log(fileName, "extractFileName");
    }
    const fileType = decodeURI(response.headers["content-type"]);
    saveFile(fileData, fileName, fileType);
  });
}

function S4() {
  return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
}
export function guid() {
  return S4() + S4() + S4() + S4() + S4() + S4() + S4() + S4();
}
