import axios, { type InternalAxiosRequestConfig, type AxiosResponse } from "axios";
import qs from "qs";
import { useUserStoreHook } from "@/store/modules/user";
import { ConfigEnum, ResultEnum } from "@/enums/ResultEnum";
import { getAccessToken } from "@/utils/auth";
import { joinTimestamp } from "@/utils";
import router from "@/router";
import { isString } from "./is";

// 创建 axios 实例
const service = axios.create({
  baseURL: import.meta.env.VITE_APP_BASE_API,
  timeout: 50000,
  headers: { "Content-Type": "application/json;charset=utf-8" },
  paramsSerializer: (params) => qs.stringify(params),
});

// 请求拦截器
service.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const accessToken = getAccessToken();
    // 如果 Authorization 设置为 no-auth，则不携带 Token，用于登录、刷新 Token 等接口
    if (config.headers.Authorization !== "no-auth" && accessToken) {
      config.headers.Authorization = `Bearer ${accessToken}`;
      config.headers[ConfigEnum.VERSION] = "v3";
      config.headers[ConfigEnum.TOKEN] = accessToken;
    } else {
      delete config.headers.Authorization;
    }

    if (config.method?.toUpperCase() === "GET") {
      const params = config.params || {};
      const joinTime = true;
      if (!isString(params)) {
        // 给 get 请求加上时间戳参数，避免从缓存中拿数据。
        config.params = Object.assign(params || {}, joinTimestamp(joinTime, false));
      } else {
        // 兼容restful风格
        config.url = config.url + params + `${joinTimestamp(joinTime, true)}`;
        config.params = undefined;
      }
    }

    return config;
  },
  (error) => Promise.reject(error)
);

// 响应拦截器
service.interceptors.response.use(
  (response: AxiosResponse) => {
    // 如果响应是二进制流，则直接返回，用于下载文件、Excel 导出等
    if (response.config.responseType === "blob") {
      return response;
    }

    if (!response.data) return;

    if (Reflect.has(response.data, "code")) {
      // 配套 Java 后端jeecg-boot
      const { code, result, msg } = response.data;
      if ([ResultEnum.SUCCESS, ResultEnum.SUCCESS_CODE].includes(code)) {
        return result ?? response.data;
      } else {
        if (!response.config.showErrorMsg) return response.data;
        return ElMessage.error(msg || "系统出错");
      }
    } else if (Reflect.has(response.data, "state")) {
      // 这里逻辑可以根据项目进行修改
      const { state, resMsg } = response.data;
      const hasResObjSuccess = response.data && Reflect.has(response.data, "state") && state;
      if (hasResObjSuccess) {
        console.log(`post合规接口调用成功：${response.config.url}`);
        return response.data;
      } else {
        console.log(`post合规接口报错：${response.config.url}`);
        if (!response.config?.showErrorMsg) return response.data;
        return ElMessage.error(resMsg || "系统出错");
      }
    }

    return response.data;
  },
  async (error) => {
    console.error("request error", error); // for debug
    // 非 2xx 状态码处理 401、403、500 等
    const { config, response } = error;
    if (response) {
      const { code, msg } = response.data;
      if (code === ResultEnum.ACCESS_TOKEN_INVALID) {
        // Token 过期，刷新 Token
        return handleTokenRefresh(config);
      } else if (code === ResultEnum.REFRESH_TOKEN_INVALID) {
        return Promise.reject(new Error(msg || "Error"));
      } else {
        ElMessage.error(msg || "系统出错");
      }
    }
    return Promise.reject(error.message);
  }
);

export default service;

// 是否正在刷新标识，避免重复刷新
let isRefreshing = false;
// 因 Token 过期导致的请求等待队列
const waitingQueue: Array<() => void> = [];

// 刷新 Token 处理
async function handleTokenRefresh(config: InternalAxiosRequestConfig) {
  return new Promise((resolve) => {
    // 封装需要重试的请求
    const retryRequest = () => {
      config.headers.Authorization = getAccessToken();
      resolve(service(config));
    };

    waitingQueue.push(retryRequest);

    if (!isRefreshing) {
      isRefreshing = true;

      // 刷新 Token
      useUserStoreHook()
        .refreshToken()
        .then(() => {
          // 依次重试队列中所有请求, 重试后清空队列
          waitingQueue.forEach((callback) => callback());
          waitingQueue.length = 0;
        })
        .catch((error: any) => {
          console.log("handleTokenRefresh error", error);
          // 刷新 Token 失败，跳转登录页
          ElNotification({
            title: "提示",
            message: "您的会话已过期，请重新登录",
            type: "info",
          });
          useUserStoreHook()
            .clearUserData()
            .then(() => {
              router.push("/login");
            });
        })
        .finally(() => {
          isRefreshing = false;
        });
    }
  });
}
